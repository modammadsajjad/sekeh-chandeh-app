package com.sekehchandeh.user;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.InputType;
import android.widget.EditText;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.sekehchandeh.core.*;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
public class UserActivity extends BaseActivity {
  static final Auth.Next NEXT = new Auth.Next() { public Screen make() { return mainScreen(); } };
  @Override protected void start() {
    Api.onAuthFail = new Runnable() { public void run() { Session.clear(); Fx.toast(UserActivity.this, "لطفاً دوباره وارد شوید."); replaceAll(new Auth.Login(NEXT, false)); } };
    replaceAll(new Auth.Splash(NEXT, false));
  }
  static Screen mainScreen() {
    ArrayList<TabsScreen.Tab> t = new ArrayList<TabsScreen.Tab>();
    t.add(new TabsScreen.Tab("خرید", "coin", UserActivity::buy));
    t.add(new TabsScreen.Tab("فروش", "chart", UserActivity::sell));
    t.add(new TabsScreen.Tab("خانه", "home", UserActivity::home));
    t.add(new TabsScreen.Tab("حساب", "user", UserActivity::account));
    t.add(new TabsScreen.Tab("بیشتر", "list", UserActivity::more));
    return new TabsScreen("سکه چنده", t.toArray(new TabsScreen.Tab[0]), 2);
  }
  static void open(Context a, String url) { try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { } }
  static TextView sec(Context a, String s) { TextView t = Fx.gold(a, s, 17); t.setPadding(0, Fx.dp(a, 16), 0, Fx.dp(a, 8)); return t; }
  static View step(Context a, String n, String t, String d) {
    LinearLayout c = Fx.card(a); LinearLayout r = Fx.hbox(a); c.addView(r);
    TextView i = Fx.gold(a, Fx.fa(n), 18); i.setGravity(Gravity.CENTER); i.setMinWidth(Fx.dp(a, 40)); r.addView(i);
    LinearLayout x = Fx.vbox(a); x.setPadding(Fx.dp(a, 10), 0, 0, 0); x.addView(Fx.text(a, t, 15, Fx.TX)); x.addView(Fx.text(a, d, 12, Fx.MU)); r.addView(x);
    return c;
  }
  static View faq(Context a, String q, String ans) {
    final LinearLayout c = Fx.card(a); c.addView(Fx.text(a, "❓ " + q, 15, Fx.GOLD2));
    final TextView t = Fx.text(a, ans, 13, Fx.MU); t.setVisibility(View.GONE); c.addView(t, Fx.lp(a, Fx.MATCH, Fx.WRAP, 8));
    c.setOnClickListener(v -> t.setVisibility(t.getVisibility() == View.GONE ? View.VISIBLE : View.GONE));
    return c;
  }
  static View buy(final BaseActivity a) {
    LinearLayout box = Fx.vbox(a); LinearLayout c = Fx.card(a); box.addView(c);
    c.setGravity(Gravity.CENTER); c.addView(Fx.gold(a, "خرید فعلاً بسته است", 18)); c.addView(Fx.text(a, "به‌زودی باز می‌شود.", 14, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 8));
    return scroller(a, box);
  }
  static View sell(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); final LinearLayout c = Fx.card(a); box.addView(c);
    c.addView(Fx.gold(a, "فروش سکه", 18));
    c.addView(Fx.text(a, "سکه را به شماره‌ی اعلام‌شده منتقل کنید و درخواست را ثبت کنید.", 13, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 6));
    final String[] plat = {""}; final long[] price = {0};
    final LinearLayout chips = Fx.hbox(a); final android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(a); hs.addView(chips);
    c.addView(Fx.text(a, "پلتفرم", 13, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 12)); c.addView(hs);
    final EditText am = Fx.input(a, "تعداد سکه، مثلاً ۱۰", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
    final TextView pay = Fx.text(a, "", 16, Fx.GOLD2); pay.setGravity(Gravity.CENTER);
    c.addView(am, Fx.lp(a, Fx.MATCH, Fx.WRAP, 10)); c.addView(pay, Fx.lp(a, Fx.MATCH, Fx.WRAP, 8));
    final Runnable calc = () -> { try { double n = Double.parseDouble(am.getText().toString().trim()); pay.setText(price[0] > 0 ? "مبلغ دریافتی: " + Fx.num(Math.round(n * price[0])) + " تومان" : ""); } catch (Exception e) { pay.setText(""); } };
    am.addTextChangedListener(new android.text.TextWatcher() { public void beforeTextChanged(CharSequence s, int x, int y, int z) { } public void onTextChanged(CharSequence s, int x, int y, int z) { calc.run(); } public void afterTextChanged(android.text.Editable e) { } });
    final JSONArray[] coins = {null};
    final Runnable[] draw = new Runnable[1];
    draw[0] = () -> { chips.removeAllViews(); if (coins[0] == null) return;
      for (int i = 0; i < coins[0].length(); i++) { final JSONObject co = coins[0].optJSONObject(i); LinearLayout.LayoutParams p = Fx.lp(a, Fx.WRAP, Fx.WRAP, 6); p.setMarginEnd(Fx.dp(a, 8));
        chips.addView(Fx.chip(a, co.optString("name"), co.optString("name").equals(plat[0]), v -> { plat[0] = co.optString("name"); price[0] = co.optLong("sell_price"); draw[0].run(); calc.run(); }), p); } };
    Api.get("/api/coins", (r, e) -> { if (r != null) { coins[0] = r.optJSONArray("coins"); draw[0].run(); } });
    final boolean[] toWallet = {false};
    final LinearLayout wr = Fx.hbox(a); c.addView(Fx.text(a, "دریافت مبلغ در", 13, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 12)); c.addView(wr);
    final Runnable[] dw = new Runnable[1];
    dw[0] = () -> { wr.removeAllViews();
      wr.addView(Fx.chip(a, "کارت بانکی", !toWallet[0], v -> { toWallet[0] = false; dw[0].run(); }), Fx.wt(a, 1, 6));
      wr.addView(Fx.chip(a, "کیف پول", toWallet[0], v -> { toWallet[0] = true; dw[0].run(); }), Fx.wt(a, 1, 6)); };
    dw[0].run();
    final EditText cd = Fx.input(a, "شماره کارت ۱۶ رقمی", InputType.TYPE_CLASS_NUMBER); c.addView(cd, Fx.lp(a, Fx.MATCH, Fx.WRAP, 10));
    final String[] shot = {null}; final TextView sh = Fx.text(a, "", 12, Fx.OK);
    c.addView(Fx.ghost(a, "📷 انتخاب اسکرین‌شات انتقال", v -> a.pickImage(d -> { shot[0] = d; sh.setText("✓ عکس انتخاب شد"); })), Fx.lp(a, Fx.MATCH, Fx.WRAP, 10)); c.addView(sh);
    final TextView msg = Fx.text(a, "", 13, Fx.BAD); c.addView(msg, Fx.lp(a, Fx.WRAP, Fx.WRAP, 8));
    c.addView(Fx.button(a, "ثبت درخواست فروش", v -> {
      if (plat[0].isEmpty() || am.getText().toString().trim().isEmpty() || shot[0] == null) { msg.setText("پلتفرم، تعداد و عکس را کامل کنید."); msg.setTextColor(Fx.BAD); return; }
      msg.setText("در حال ارسال…"); msg.setTextColor(Fx.MU);
      Api.post("/api/orders", Api.obj("platform", plat[0], "amount", am.getText().toString().trim(), "payout", toWallet[0] ? "wallet" : "card", "card", cd.getText().toString().trim(), "screenshot", shot[0]), (r, e) -> {
        if (e != null) { msg.setText(e); msg.setTextColor(Fx.BAD); return; }
        msg.setText("درخواست ثبت شد ✓"); msg.setTextColor(Fx.OK); am.setText(""); shot[0] = null; sh.setText(""); });
    }), Fx.lp(a, Fx.MATCH, Fx.WRAP, 8));
    return scroller(a, box);
  }
  static View more(final BaseActivity a) {
    LinearLayout box = Fx.vbox(a);
    box.addView(Fx.gold(a, "بیشتر", 18));
    box.addView(Fx.button(a, "💬 پشتیبانی در بله", v -> open(a, "https://ble.ir/postibani")), Fx.lp(a, Fx.MATCH, Fx.WRAP, 12));
    box.addView(Fx.ghost(a, "📢 کانال @sakehchandeh", v -> open(a, "https://ble.ir/sakehchandeh")), Fx.lp(a, Fx.MATCH, Fx.WRAP, 10));
    if (Api.feature("leaderboard")) box.addView(Fx.ghost(a, "🏆 رتبه‌بندی", v -> a.push(new Screen() { public View create() { return rank(act); } })), Fx.lp(a, Fx.MATCH, Fx.WRAP, 10));
    box.addView(Fx.ghost(a, "🚪 خروج از حساب", v -> Fx.confirm(a, "از حساب خارج می‌شوید؟", () -> { Session.clear(); a.replaceAll(new Auth.Login(NEXT, false)); })), Fx.lp(a, Fx.MATCH, Fx.WRAP, 10));
    return scroller(a, box);
  }
  static ScrollView scroller(Context a, LinearLayout box) { int p = Fx.dp(a, 14); box.setPadding(p, p, p, p); ScrollView sc = new ScrollView(a); sc.addView(box); return sc; }
  static LinearLayout row3(Context a, String x, String y, String z, int c1, int c2, int c3) {
    LinearLayout r = Fx.hbox(a); r.setPadding(0, Fx.dp(a, 7), 0, Fx.dp(a, 7));
    TextView n = Fx.text(a, x, 15, c1); TextView b = Fx.text(a, y, 15, c2); TextView s = Fx.text(a, z, 15, c3);
    b.setGravity(Gravity.CENTER); s.setGravity(Gravity.CENTER);
    r.addView(n, new LinearLayout.LayoutParams(0, Fx.WRAP, 1.4f)); r.addView(b, new LinearLayout.LayoutParams(0, Fx.WRAP, 1f)); r.addView(s, new LinearLayout.LayoutParams(0, Fx.WRAP, 1f));
    return r;
  }
  static View home(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a);
    LinearLayout hero = Fx.card(a); hero.setGravity(Gravity.CENTER); box.addView(hero);
    final ImageView hc = Fx.logo(a, 170); hero.addView(hc);
    hero.addView(Fx.gold(a, "خرید و فروش سکه", 22), Fx.lp(a, Fx.WRAP, Fx.WRAP, 8));
    hero.addView(Fx.text(a, "بله، روبیکا، گپ روبیکا و روبیستا", 13, Fx.MU));
    LinearLayout hb = Fx.hbox(a); hb.addView(Fx.button(a, "خرید سکه", v -> TabsScreen.last.goTo(0)), Fx.wt(a, 1, 0)); hb.addView(Fx.ghost(a, "فروش سکه", v -> TabsScreen.last.goTo(1)), Fx.wt(a, 1, 0));
    hero.addView(hb, Fx.lp(a, Fx.MATCH, Fx.WRAP, 12));
    LinearLayout pc = Fx.card(a); box.addView(pc, Fx.lp(a, Fx.MATCH, Fx.WRAP, 14));
    pc.addView(Fx.gold(a, "قیمت سکه‌ها", 18));
    final LinearLayout list = Fx.vbox(a); pc.addView(list, Fx.lp(a, Fx.MATCH, Fx.WRAP, 8));
    list.addView(Fx.text(a, "در حال بارگذاری…", 13, Fx.MU));
    Api.get("/api/coins", (r, e) -> {
      list.removeAllViews();
      if (e != null) { list.addView(Fx.text(a, e, 14, Fx.BAD)); return; }
      JSONArray cs = r.optJSONArray("coins");
      if (cs == null || cs.length() == 0) { list.addView(Fx.text(a, "هنوز قیمتی ثبت نشده است.", 14, Fx.MU)); return; }
      list.addView(row3(a, "سکه", "خرید", "فروش", Fx.GOLD, Fx.GOLD, Fx.GOLD));
      for (int i = 0; i < cs.length(); i++) { JSONObject c = cs.optJSONObject(i);
        list.addView(row3(a, c.optString("name"), Fx.num(c.optLong("buy_price")), Fx.num(c.optLong("sell_price")), Fx.TX, Fx.TX, Fx.GOLD2)); }
    });
    if (Api.feature("announcements")) {
      final LinearLayout ac = Fx.card(a); box.addView(ac, Fx.lp(a, Fx.MATCH, Fx.WRAP, 14)); ac.setVisibility(View.GONE);
      Api.get("/api/announcements", (r, e) -> {
        JSONArray an = r == null ? null : r.optJSONArray("announcements");
        if (an == null || an.length() == 0) return;
        ac.setVisibility(View.VISIBLE); ac.addView(Fx.gold(a, "اعلان‌ها", 18));
        for (int i = 0; i < Math.min(3, an.length()); i++) { JSONObject x = an.optJSONObject(i);
          ac.addView(Fx.text(a, x.optString("title"), 15, Fx.GOLD2), Fx.lp(a, Fx.WRAP, Fx.WRAP, 10));
          if (!TextUtils.isEmpty(x.optString("body"))) ac.addView(Fx.text(a, x.optString("body"), 13, Fx.MU)); }
      });
    }
    final LinearLayout cc = Fx.card(a); box.addView(cc, Fx.lp(a, Fx.MATCH, Fx.WRAP, 14)); cc.setVisibility(View.GONE);
    Api.get("/api/settings", (r, e) -> {
      JSONObject s = r == null ? null : r.optJSONObject("settings");
      if (s == null || s.length() == 0) return;
      cc.setVisibility(View.VISIBLE); cc.addView(Fx.gold(a, "ارتباط با ما", 18));
      if (s.has("support_id")) cc.addView(Fx.text(a, "پشتیبانی: " + s.optString("support_id"), 14, Fx.TX), Fx.lp(a, Fx.WRAP, Fx.WRAP, 8));
      if (s.has("channel_link")) cc.addView(Fx.text(a, "کانال: " + s.optString("channel_link"), 14, Fx.TX), Fx.lp(a, Fx.WRAP, Fx.WRAP, 6));
    });
    box.addView(sec(a, "🚀 چطور شروع کنیم؟"));
    box.addView(step(a, "1", "ثبت‌نام", "یک حساب رایگان بسازید."), Fx.lp(a, Fx.MATCH, Fx.WRAP, 0));
    box.addView(step(a, "2", "انتخاب سکه", "پلتفرم و تعداد سکه را مشخص کنید."), Fx.lp(a, Fx.MATCH, Fx.WRAP, 8));
    box.addView(step(a, "3", "انتقال", "سکه را به شماره‌ی اعلام‌شده منتقل کنید."), Fx.lp(a, Fx.MATCH, Fx.WRAP, 8));
    box.addView(step(a, "4", "ارسال درخواست", "درخواست را همراه اسکرین‌شات ثبت کنید."), Fx.lp(a, Fx.MATCH, Fx.WRAP, 8));
    box.addView(sec(a, "❓ سؤالات متداول"));
    box.addView(faq(a, "چطور سکه بفروشم؟", "از منوی فروش، پلتفرم و تعداد را وارد کنید، سکه را منتقل کنید و درخواست را با اسکرین‌شات ثبت کنید."), Fx.lp(a, Fx.MATCH, Fx.WRAP, 0));
    box.addView(faq(a, "خرید سکه فعال است؟", "فعلاً خرید بسته است و به‌زودی باز می‌شود."), Fx.lp(a, Fx.MATCH, Fx.WRAP, 8));
    box.addView(faq(a, "پشتیبانی چطور است؟", "از طریق بله با آیدی @POSTIBANI."), Fx.lp(a, Fx.MATCH, Fx.WRAP, 8));
    return scroller(a, box);
  }
  static int[] placeColors(int place) {
    if (place == 1) return new int[]{0xFFF7DF91, 0xFFE7B94F, 0xFF9B7421};
    if (place == 2) return new int[]{0xFFF2F2F7, 0xFFB8B8C4, 0xFF6E6E7C};
    return new int[]{0xFFF0B27A, 0xFFC27B3E, 0xFF7A4520};
  }
  static TextView avatar(Context a, String name, int sizeDp, int ring) {
    String l = TextUtils.isEmpty(name) ? "؟" : name.substring(0, 1).toUpperCase();
    TextView t = Fx.gold(a, l, sizeDp / 2.6f); t.setGravity(Gravity.CENTER);
    GradientDrawable g = new GradientDrawable(); g.setShape(GradientDrawable.OVAL); g.setColor(0xFF140F06); g.setStroke(Fx.dp(a, 3), ring);
    t.setBackground(g); t.setLayoutParams(new LinearLayout.LayoutParams(Fx.dp(a, sizeDp), Fx.dp(a, sizeDp)));
    return t;
  }
  static View podCol(Context a, int place, JSONObject u, int hDp, int j) {
    int[] pc = placeColors(place);
    LinearLayout col = Fx.vbox(a); col.setGravity(Gravity.CENTER_HORIZONTAL);
    ImageView crown = new ImageView(a); crown.setImageDrawable(Icons.icon(a, "crown", place == 1 ? 38 : 30, pc[0], pc[2])); col.addView(crown);
    String name = u == null ? "—" : u.optString("username");
    col.addView(avatar(a, name, place == 1 ? 70 : 60, pc[1]), Fx.lp(a, place == 1 ? Fx.dp(a, 70) : Fx.dp(a, 60), place == 1 ? Fx.dp(a, 70) : Fx.dp(a, 60), 2));
    TextView nm = Fx.text(a, name, 13, Fx.TX); nm.setSingleLine(true); nm.setEllipsize(TextUtils.TruncateAt.END); nm.setGravity(Gravity.CENTER);
    col.addView(nm, Fx.lp(a, Fx.MATCH, Fx.WRAP, 4));
    LinearLayout pr = Fx.hbox(a); pr.setGravity(Gravity.CENTER);
    if (u != null) { ImageView ci = new ImageView(a); ci.setImageDrawable(Icons.gold(a, "coin", 15)); pr.addView(ci);
      TextView pt = Fx.text(a, Fx.num(u.optLong("points")), 13, Fx.GOLD2); pt.setPadding(Fx.dp(a, 4), 0, 0, 0); pr.addView(pt); }
    col.addView(pr, Fx.lp(a, Fx.MATCH, Fx.WRAP, 2));
    TextView ped = Fx.text(a, Fx.fa(String.valueOf(place)), 28, 0xFF1B1405); ped.setGravity(Gravity.CENTER); ped.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    float r = Fx.dp(a, 14);
    GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, pc); g.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0}); g.setStroke(Fx.dp(a, 1), 0xFFFFE9A8);
    ped.setBackground(g); col.addView(ped, Fx.lp(a, Fx.MATCH, Fx.dp(a, hDp), 6));
    ped.setPivotY(Fx.dp(a, hDp)); ped.setScaleY(0f); ped.animate().scaleY(1f).setStartDelay(120L * j).setDuration(550).start();
    col.setAlpha(0f); col.animate().alpha(1f).setStartDelay(120L * j).setDuration(450).start();
    return col;
  }
  static View podium(Context a, JSONArray top) {
    LinearLayout row = Fx.hbox(a); row.setGravity(Gravity.BOTTOM); row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
    int[] order = {1, 0, 2}; int[] hs = {78, 104, 62};
    for (int j = 0; j < 3; j++) { int idx = order[j]; JSONObject u = idx < top.length() ? top.optJSONObject(idx) : null;
      LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Fx.WRAP, 1f); p.setMargins(Fx.dp(a, 4), 0, Fx.dp(a, 4), 0);
      row.addView(podCol(a, idx + 1, u, hs[j], j), p); }
    return row;
  }
  static View rankRow(Context a, JSONObject u) {
    LinearLayout r = Fx.hbox(a); r.setBackground(Fx.cardBg(a, 14)); r.setPadding(Fx.dp(a, 12), Fx.dp(a, 8), Fx.dp(a, 12), Fx.dp(a, 11));
    TextView n = Fx.text(a, Fx.fa(String.valueOf(u.optInt("rank"))), 16, Fx.MU); n.setMinWidth(Fx.dp(a, 34)); r.addView(n);
    r.addView(avatar(a, u.optString("username"), 38, Fx.GOLD3));
    TextView nm = Fx.text(a, u.optString("username"), 15, Fx.TX); nm.setPadding(Fx.dp(a, 10), 0, Fx.dp(a, 10), 0); r.addView(nm, new LinearLayout.LayoutParams(0, Fx.WRAP, 1f));
    ImageView ci = new ImageView(a); ci.setImageDrawable(Icons.gold(a, "coin", 18)); r.addView(ci);
    TextView pt = Fx.text(a, Fx.num(u.optLong("points")), 15, Fx.GOLD2); pt.setPadding(Fx.dp(a, 5), 0, 0, 0); r.addView(pt);
    return r;
  }
  static View rank(final BaseActivity a) {
    final LinearLayout root = Fx.vbox(a);
    final String[] keys = {"daily", "weekly", "monthly"}, names = {"روزانه", "هفتگی", "ماهانه"};
    final int[] cur = {0};
    final LinearLayout tabs = Fx.hbox(a); tabs.setGravity(Gravity.CENTER); tabs.setPadding(0, Fx.dp(a, 10), 0, Fx.dp(a, 4));
    final LinearLayout body = Fx.vbox(a); final ScrollView sc = scroller(a, body);
    final LinearLayout me = Fx.card(a);
    root.addView(tabs); root.addView(sc, new LinearLayout.LayoutParams(Fx.MATCH, 0, 1f));
    LinearLayout.LayoutParams mp = Fx.lp(a, Fx.MATCH, Fx.WRAP, 0); mp.setMargins(Fx.dp(a, 14), 0, Fx.dp(a, 14), Fx.dp(a, 10)); root.addView(me, mp);
    final Runnable[] load = new Runnable[1];
    load[0] = () -> {
      tabs.removeAllViews();
      for (int i = 0; i < 3; i++) { final int k = i; LinearLayout.LayoutParams p = Fx.lp(a, Fx.WRAP, Fx.WRAP, 0); p.setMarginEnd(Fx.dp(a, 8));
        tabs.addView(Fx.chip(a, names[i], i == cur[0], v -> { cur[0] = k; load[0].run(); }), p); }
      body.removeAllViews(); me.setVisibility(View.GONE); body.addView(Fx.text(a, "در حال بارگذاری…", 13, Fx.MU));
      Api.get("/api/leaderboard?period=" + keys[cur[0]], (r, e) -> {
        body.removeAllViews();
        if (e != null) { body.addView(Fx.text(a, e, 14, Fx.BAD)); return; }
        JSONArray top = r.optJSONArray("top");
        if (top == null || top.length() == 0) { body.addView(Fx.text(a, "هنوز کسی امتیاز نگرفته است.", 14, Fx.MU)); return; }
        body.addView(podium(a, top));
        for (int i = 3; i < top.length(); i++) body.addView(rankRow(a, top.optJSONObject(i)), Fx.lp(a, Fx.MATCH, Fx.WRAP, 8));
        JSONObject m = r.optJSONObject("me");
        me.removeAllViews(); me.setVisibility(View.VISIBLE);
        me.addView(Fx.text(a, m == null ? "هنوز امتیازی ندارید." : "رتبه شما: " + Fx.fa(String.valueOf(m.optInt("rank"))) + "   •   " + Fx.num(m.optLong("points")) + " امتیاز", 15, Fx.GOLD2));
      });
    };
    load[0].run();
    return root;
  }
  static View account(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a);
    final LinearLayout c = Fx.card(a); box.addView(c);
    c.addView(Fx.text(a, "در حال بارگذاری…", 13, Fx.MU));
    Api.get("/api/me", (r, e) -> {
      c.removeAllViews();
      if (e != null) { c.addView(Fx.text(a, e, 14, Fx.BAD)); return; }
      JSONObject u = r.optJSONObject("user");
      c.addView(Fx.gold(a, u.optString("username"), 22));
      c.addView(Fx.text(a, "موبایل: " + Fx.fa(u.optString("phone")), 14, Fx.TX), Fx.lp(a, Fx.WRAP, Fx.WRAP, 8));
      String cd = u.optString("card"); if (cd.length() == 16) c.addView(Fx.text(a, "کارت: " + Fx.fa(cd.substring(0, 4) + " **** **** " + cd.substring(12)), 14, Fx.TX), Fx.lp(a, Fx.WRAP, Fx.WRAP, 6));
    });
    box.addView(Fx.button(a, "خروج از حساب", v -> Fx.confirm(a, "از حساب خارج می‌شوید؟", () -> { Session.clear(); a.replaceAll(new Auth.Login(NEXT, false)); })), Fx.lp(a, Fx.MATCH, Fx.WRAP, 16));
    return scroller(a, box);
  }
}
