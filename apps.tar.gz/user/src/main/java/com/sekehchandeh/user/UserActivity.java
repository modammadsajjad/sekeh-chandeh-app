package com.sekehchandeh.user;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.sekehchandeh.core.*;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
public class UserActivity extends BaseActivity {
  static final Auth.Next NEXT = new Auth.Next() { public Screen make() { return mainScreen(); } };
  static JSONObject CFG = new JSONObject(), WAL = new JSONObject();
  static JSONArray ORD = new JSONArray();
  @Override protected void start() {
    Api.onAuthFail = new Runnable() { public void run() { Session.clear(); Fx.toast(UserActivity.this, "لطفاً دوباره وارد شوید."); replaceAll(new Auth.Login(NEXT, false)); } };
    replaceAll(new Auth.Splash(NEXT, false));
  }
  // ---------- ساختار اصلی ----------
  static Screen mainScreen() {
    ArrayList<TabsScreen.Tab> t = new ArrayList<TabsScreen.Tab>();
    t.add(new TabsScreen.Tab("خرید", "cart", UserActivity::buy));
    t.add(new TabsScreen.Tab("فروش", "bag", UserActivity::sell));
    t.add(new TabsScreen.Tab("خانه", "home", UserActivity::home));
    t.add(new TabsScreen.Tab("حساب", "user", UserActivity::account));
    t.add(new TabsScreen.Tab("بیشتر", "list", UserActivity::more));
    final TabsScreen ts = new TabsScreen("سکه چنده", t.toArray(new TabsScreen.Tab[0]), 2);
    ts.orders = () -> ts.act.push(page("📋 سفارشات", UserActivity::ordersBody));
    ts.bell = () -> ts.act.push(page("🔔 اعلان‌ها", UserActivity::annBody));
    ts.ai = () -> ts.act.push(new AiScreen());
    return ts;
  }
  interface Body { View make(BaseActivity a); }
  static Screen page(final String title, final Body body) {
    return new Screen() { public View create() {
      final BaseActivity a = act; LinearLayout c = Fx.vbox(a); c.setBackgroundColor(0xF0080706);
      LinearLayout h = Fx.hbox(a); h.setPadding(Fx.dp(a, 16), Fx.dp(a, 14), Fx.dp(a, 16), Fx.dp(a, 6));
      h.addView(Fx.gold(a, title, 20), new LinearLayout.LayoutParams(0, Fx.WRAP, 1f));
      h.addView(Ui.pill(a, "✕", v -> a.pop()));
      c.addView(h); c.addView(body.make(a), new LinearLayout.LayoutParams(Fx.MATCH, 0, 1f)); return c; } };
  }
  static ScrollView scroller(Context a, LinearLayout box) { int p = Fx.dp(a, 14); box.setPadding(p, p, p, Fx.dp(a, 24)); ScrollView sc = new ScrollView(a); sc.setClipChildren(false); sc.addView(box); return sc; }
  static LinearLayout.LayoutParams top(Context a, float t) { return Fx.lp(a, Fx.MATCH, Fx.WRAP, t); }
  static long num(String s) { try { return Long.parseLong(s); } catch (Exception e) { return 0; } }
  static String faDigits(String s) { if (s == null) return ""; StringBuilder b = new StringBuilder(); for (char ch : s.toCharArray()) { if (ch >= '٠' && ch <= '٩') b.append((char) ('0' + (ch - '٠'))); else if (ch >= '۰' && ch <= '۹') b.append((char) ('0' + (ch - '۰'))); else b.append(ch); } return b.toString(); }
  // ---------- بارگذاری تنظیمات و قیمت‌ها ----------
  interface Done { void run(); }
  static void loadCfg(final Done d) {
    Api.get("/api/config", (r, e) -> {
      if (e == null && r != null && r.optJSONArray("coins") != null) { CFG = r; if (d != null) d.run(); return; }
      Api.get("/api/coins", (r2, e2) -> { if (r2 != null) { CFG = r2; } if (d != null) d.run(); });
    });
  }
  static JSONArray coins() { JSONArray a = CFG.optJSONArray("coins"); return a == null ? new JSONArray() : a; }
  static long buyP(JSONObject c) { return c.has("buy") ? c.optLong("buy") : c.optLong("buy_price"); }
  static long sellP(JSONObject c) { return c.has("recv") ? c.optLong("recv") : c.has("sell") ? c.optLong("sell") : c.optLong("sell_price"); }
  static int colorOf(JSONObject c) { try { return Color.parseColor(c.optString("color", "#9b6bff")); } catch (Exception e) { return 0xFF9B6BFF; } }
  static String ownerPhone() { JSONObject s = CFG.optJSONObject("settings"); return s != null && !TextUtils.isEmpty(s.optString("owner_phone")) ? s.optString("owner_phone") : "09938127009"; }
  static View dot(Context a, int color, int dp) { View v = new View(a); GradientDrawable g = new GradientDrawable(); g.setShape(GradientDrawable.OVAL); g.setColor(color); v.setBackground(g); v.setLayoutParams(new LinearLayout.LayoutParams(Fx.dp(a, dp), Fx.dp(a, dp))); return v; }
  static View statsCard(final BaseActivity a) {
    LinearLayout c = Fx.card(a); LinearLayout r = Fx.hbox(a);
    final TextView[] v = new TextView[2];
    String[] names = {"سکه‌ی ثبت‌شده برای فروش", "تعداد درخواست"};
    for (int i = 0; i < 2; i++) { LinearLayout b = Fx.vbox(a); b.setBackground(Ui.rr(a, 0x55060410, 16, 0xFF5A4720, 1)); b.setPadding(Fx.dp(a, 12), Fx.dp(a, 12), Fx.dp(a, 12), Fx.dp(a, 12));
      b.addView(Fx.text(a, names[i], 13, Fx.MU)); v[i] = Fx.text(a, "۰", 26, Fx.GOLD2); v[i].setTypeface(Typeface.DEFAULT_BOLD); b.addView(v[i], Fx.lp(a, Fx.WRAP, Fx.WRAP, 8));
      LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Fx.WRAP, 1f); p.setMargins(Fx.dp(a, 4), 0, Fx.dp(a, 4), 0); r.addView(b, p); }
    c.addView(r);
    Api.get("/api/orders/mine", (res, e) -> { if (res == null) return; JSONArray o = res.optJSONArray("orders"); if (o == null) return; ORD = o; long sold = 0; int n = 0;
      for (int i = 0; i < o.length(); i++) { JSONObject x = o.optJSONObject(i); if (x == null || "cancelled".equals(x.optString("status"))) continue; n++; if ("sell".equals(x.optString("kind"))) sold += x.optLong("qty"); }
      v[0].setText(Fx.num(sold)); v[1].setText(Fx.num(n)); });
    return c;
  }
  // ---------- خانه ----------
  static View home(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a);
    final ImageView coin = Ui.img(a, "coin3d", 150, 150, false); coin.setCameraDistance(Fx.dp(a, 4000));
    android.animation.ObjectAnimator oa = android.animation.ObjectAnimator.ofFloat(coin, "rotationY", 0f, 360f); oa.setDuration(3600); oa.setRepeatCount(android.animation.ValueAnimator.INFINITE); oa.setInterpolator(new android.view.animation.LinearInterpolator()); oa.start();
    box.addView(coin, Fx.lp(a, Fx.dp(a, 150), Fx.dp(a, 150), 8));
    TextView out = Ui.pill(a, "خروج", v -> Fx.confirm(a, "از حساب خارج می‌شوید؟", () -> { Session.clear(); a.replaceAll(new Auth.Login(NEXT, false)); }));
    box.addView(out, Fx.lp(a, Fx.WRAP, Fx.WRAP, 6));
    final TextView hi = Fx.text(a, "", 15, Fx.MU); box.addView(hi, Fx.lp(a, Fx.WRAP, Fx.WRAP, 10));
    Api.get("/api/me", (r, e) -> { if (r != null && r.optJSONObject("user") != null) hi.setText("سلام " + r.optJSONObject("user").optString("username") + "، خوش آمدید."); });
    LinearLayout hero = Fx.vbox(a); hero.setGravity(Gravity.CENTER_HORIZONTAL); box.addView(hero, top(a, 14));
    TextView badge = Fx.text(a, "🟢 قیمت‌های امروز", 14, 0xFF7DF9FF); badge.setBackground(Ui.rr(a, 0xFF1A1240, 30, 0xFF2D1D57, 1)); badge.setPadding(Fx.dp(a, 18), Fx.dp(a, 10), Fx.dp(a, 18), Fx.dp(a, 10)); hero.addView(badge);
    ImageView ht = Ui.titleImg(a, "t_hero", 64); ht.setScaleType(ImageView.ScaleType.FIT_CENTER); hero.addView(ht, Fx.lp(a, Fx.WRAP, Fx.dp(a, 64), 16));
    TextView sub = Fx.text(a, "بله، روبیکا، گپ روبیکا و روبیستا", 17, 0xFF8FB4FF); sub.setGravity(Gravity.CENTER); hero.addView(sub, Fx.lp(a, Fx.WRAP, Fx.WRAP, 14));
    TextView p3 = Fx.text(a, "ساده، سریع و کارت‌به‌کارت.", 15, Fx.MU); hero.addView(p3, Fx.lp(a, Fx.WRAP, Fx.WRAP, 14));
    LinearLayout btns = Fx.hbox(a); btns.addView(Ui.two(a, Fx.button(a, "🟢 خرید سکه", v -> TabsScreen.last.goTo(0)), Fx.button(a, "🔴 فروش سکه", v -> TabsScreen.last.goTo(1))), new LinearLayout.LayoutParams(Fx.MATCH, Fx.WRAP));
    box.addView(btns, top(a, 16));
    final LinearLayout tickCard = Ui.navy(a); final HorizontalScrollView hs = new HorizontalScrollView(a); final LinearLayout tk = Fx.hbox(a); hs.addView(tk); tickCard.addView(hs); box.addView(tickCard, top(a, 14));
    box.addView(Ui.title(a, "📊 قیمت‌ها"));
    final LinearLayout pl = Fx.vbox(a); box.addView(pl);
    Done render = () -> {
      tk.removeAllViews(); pl.removeAllViews(); JSONArray cs = coins();
      for (int i = 0; i < cs.length(); i++) { JSONObject c = cs.optJSONObject(i); LinearLayout it = Fx.hbox(a); it.addView(dot(a, colorOf(c), 14)); TextView tv = Fx.text(a, "  " + c.optString("name") + ": " + Fx.num(buyP(c)) + " | " + Fx.num(sellP(c)) + "     ", 15, Fx.TX); it.addView(tv); tk.addView(it); }
      pl.addView(priceCard(a, "خرید — شما پرداخت می‌کنید", cs, true)); pl.addView(priceCard(a, "فروش — شما دریافت می‌کنید", cs, false), top(a, 14));
    };
    loadCfg(render);
    box.addView(Ui.title(a, "🚀 چطور شروع کنیم؟"));
    String[][] st = {{"۱", "📝 ثبت‌نام", "یک حساب رایگان بسازید."}, {"۲", "🪙 انتخاب سکه", "پلتفرم و تعداد سکه را مشخص کنید."}, {"۳", "🔁 انتقال", "سکه را به شماره‌ی اعلام‌شده منتقل کنید."}, {"۴", "✅ ارسال درخواست", "درخواست خود را همراه اسکرین‌شات ثبت کنید."}};
    for (int i = 0; i < 4; i++) { LinearLayout c = Fx.card(a); LinearLayout r = Fx.hbox(a); r.setPadding(0, Fx.dp(a, 6), 0, Fx.dp(a, 6));
      TextView n = Fx.text(a, st[i][0], 22, 0xFF1B1405); n.setTypeface(Typeface.DEFAULT_BOLD); n.setGravity(Gravity.CENTER);
      GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFFF1D98C, 0xFFC9962E}); g.setShape(GradientDrawable.OVAL); n.setBackground(g);
      r.addView(n, new LinearLayout.LayoutParams(Fx.dp(a, 54), Fx.dp(a, 54)));
      LinearLayout x = Fx.vbox(a); x.setPadding(Fx.dp(a, 14), 0, 0, 0); TextView t1 = Fx.text(a, st[i][1], 18, Fx.TX); t1.setTypeface(Typeface.DEFAULT_BOLD); x.addView(t1); x.addView(Fx.text(a, st[i][2], 14, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 4));
      r.addView(x, new LinearLayout.LayoutParams(0, Fx.WRAP, 1f)); c.addView(r); box.addView(c, top(a, 10)); }
    box.addView(Ui.title(a, "❓ سؤالات متداول"));
    box.addView(faq(a, "چطور سکه بفروشم؟", "از منوی فروش، پلتفرم و تعداد سکه را وارد کنید، سکه را به شماره‌ی نمایش‌داده‌شده منتقل کنید و درخواست خود را همراه اسکرین‌شات ثبت کنید."), top(a, 0));
    box.addView(faq(a, "خرید سکه فعال است؟", "فعلاً خرید بسته است و به‌زودی باز می‌شود."), top(a, 10));
    box.addView(faq(a, "مبلغ فروش چطور حساب می‌شود؟", "قیمت هر سکه در پلتفرم انتخابی ضرب در تعداد سکه. مبلغ در فرم فروش خودکار نمایش داده می‌شود."), top(a, 10));
    box.addView(faq(a, "پشتیبانی چطور است؟", "از طریق بله با آیدی @POSTIBANI."), top(a, 10));
    box.addView(Fx.button(a, "💬 پشتیبانی در بله", v -> Ui.openUrl(a, "https://ble.ir/postibani")), top(a, 16));
    LinearLayout ch = new LinearLayout(a); ch.setOrientation(LinearLayout.HORIZONTAL); ch.setGravity(Gravity.CENTER_VERTICAL); ch.setBackground(Ui.rr(a, 0xFF4F370C, 24, 0xFF8C682C, 1)); ch.setPadding(Fx.dp(a, 14), Fx.dp(a, 14), Fx.dp(a, 14), Fx.dp(a, 14));
    ch.addView(Ui.img(a, "chan", 76, 76, true));
    TextView ct = Fx.text(a, "همین حالا به کانال بپیوندید تا از دستمان ندهید\n@sakehchandeh", 15, Fx.TX); ct.setPadding(Fx.dp(a, 12), 0, Fx.dp(a, 12), 0); ch.addView(ct, new LinearLayout.LayoutParams(0, Fx.WRAP, 1f));
    TextView jn = Fx.text(a, "پیوستن", 14, 0xFF211604); jn.setTypeface(Typeface.DEFAULT_BOLD); jn.setBackground(Ui.goldBg(a, 16)); jn.setPadding(Fx.dp(a, 16), Fx.dp(a, 12), Fx.dp(a, 16), Fx.dp(a, 12)); ch.addView(jn);
    ch.setOnClickListener(v -> Ui.openUrl(a, "https://ble.ir/sakehchandeh")); box.addView(ch, top(a, 16));
    return scroller(a, box);
  }
  static View priceCard(Context a, String head, JSONArray cs, boolean buy) {
    LinearLayout c = Fx.card(a); LinearLayout h = Fx.hbox(a); h.addView(dot(a, Fx.GOLD, 14)); TextView t = Fx.text(a, "  " + head, 18, Fx.TX); t.setTypeface(Typeface.DEFAULT_BOLD); h.addView(t); c.addView(h);
    View ln = new View(a); ln.setBackgroundColor(0x55725522); c.addView(ln, Fx.lp(a, Fx.MATCH, Fx.dp(a, 1), 12));
    for (int i = 0; i < cs.length(); i++) { JSONObject co = cs.optJSONObject(i); long v = buy ? buyP(co) : sellP(co);
      LinearLayout r = Fx.hbox(a); r.setPadding(0, Fx.dp(a, 12), 0, Fx.dp(a, 4)); r.addView(dot(a, colorOf(co), 34));
      TextView nm = Fx.text(a, "  سکه " + co.optString("name"), 18, Fx.TX); r.addView(nm, new LinearLayout.LayoutParams(0, Fx.WRAP, 1f));
      TextView pr = Fx.text(a, v > 0 ? Fx.num(v) + " ت" : "غیرفعال", 22, v > 0 ? Fx.GOLD : Fx.MU); pr.setTypeface(Typeface.DEFAULT_BOLD); r.addView(pr); c.addView(r);
      if (buy) { long st = co.optLong("stock"); c.addView(Fx.text(a, "موجودی: " + (st > 0 ? Fx.num(st) + " عدد" : "ناموجود"), 13, Fx.MU)); } }
    return c;
  }
  static View faq(Context a, String q, String ans) {
    final LinearLayout c = Ui.navy(a); c.addView(Fx.text(a, "◀  " + q, 17, Fx.TX));
    final TextView t = Fx.text(a, ans, 14, Fx.MU); t.setVisibility(View.GONE); c.addView(t, Fx.lp(a, Fx.MATCH, Fx.WRAP, 10));
    c.setOnClickListener(v -> t.setVisibility(t.getVisibility() == View.GONE ? View.VISIBLE : View.GONE)); return c;
  }
  // ---------- خرید ----------
  static View buy(final BaseActivity a) {
    LinearLayout box = Fx.vbox(a); LinearLayout c = Fx.card(a); c.setGravity(Gravity.CENTER); c.setPadding(Fx.dp(a, 16), Fx.dp(a, 36), Fx.dp(a, 16), Fx.dp(a, 36));
    c.addView(Fx.gold(a, "خرید فعلاً بسته است", 22)); c.addView(Fx.text(a, "به‌زودی باز می‌شود.", 17, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 18)); box.addView(c);
    box.addView(statsCard(a), top(a, 14)); return scroller(a, box);
  }
  // ---------- فروش ----------
  static View sell(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); final LinearLayout c = Fx.card(a); box.addView(c);
    c.addView(Fx.text(a, "📈 سکه را به این شماره انتقال دهید:", 15, Fx.TX));
    final LinearLayout nb = Fx.hbox(a); nb.setBackground(Ui.rr(a, Ui.NAVY, 20, 0xFFE7B94F, 1.5f)); nb.setPadding(Fx.dp(a, 12), Fx.dp(a, 12), Fx.dp(a, 12), Fx.dp(a, 12)); nb.setGravity(Gravity.CENTER);
    TextView num = Fx.text(a, Fx.fa(ownerPhone()), 24, 0xFFF7DF91); num.setTypeface(Typeface.DEFAULT_BOLD); num.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
    TextView cp = Fx.text(a, "⧉", 22, 0xFF211604); cp.setGravity(Gravity.CENTER); cp.setBackground(Ui.goldBg(a, 14));
    cp.setOnClickListener(v -> { ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("n", ownerPhone())); Fx.toast(a, "شماره کپی شد."); });
    nb.addView(cp, new LinearLayout.LayoutParams(Fx.dp(a, 46), Fx.dp(a, 46))); nb.addView(num, new LinearLayout.LayoutParams(0, Fx.WRAP, 1f));
    c.addView(nb, top(a, 12));
    final String[] plat = {""}; final long[] price = {0}; final boolean[] toWallet = {false};
    final EditText am = Fx.input(a, "مثلاً ۱۰", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL); am.setBackground(Ui.rr(a, Ui.NAVY, 14, 0xFF5A4720, 1));
    final TextView pay = Fx.text(a, "", 18, Fx.GOLD2); pay.setGravity(Gravity.CENTER);
    final Runnable calc = () -> { try { double n = Double.parseDouble(faDigits(am.getText().toString().trim())); pay.setText(price[0] > 0 ? "مبلغ دریافتی: " + Fx.num(Math.round(n * price[0])) + " تومان" : ""); } catch (Exception e) { pay.setText(""); } };
    am.addTextChangedListener(new android.text.TextWatcher() { public void beforeTextChanged(CharSequence s, int x, int y, int z) { } public void onTextChanged(CharSequence s, int x, int y, int z) { calc.run(); } public void afterTextChanged(android.text.Editable e) { } });
    final String[][] names = {new String[0]};
    final TextView sel = Ui.select(a, "انتخاب", new String[]{"بله", "روبیکا", "گپ روبیکا", "روبیستا"}, i -> { });
    final LinearLayout pfBox = Fx.vbox(a); pfBox.addView(Ui.label(a, "پلتفرم")); pfBox.addView(sel);
    LinearLayout amBox = Fx.vbox(a); amBox.addView(Ui.label(a, "تعداد سکه")); amBox.addView(am);
    c.addView(Ui.two(a, pfBox, amBox), top(a, 4));
    final TextView[] pfv = {sel};
    loadCfg(() -> { JSONArray cs = coins(); if (cs.length() == 0) return; final String[] nm = new String[cs.length()]; for (int i = 0; i < cs.length(); i++) nm[i] = cs.optJSONObject(i).optString("name");
      TextView s2 = Ui.select(a, "انتخاب", nm, i -> { plat[0] = nm[i]; price[0] = sellP(coins().optJSONObject(i)); calc.run(); }); pfBox.removeAllViews(); pfBox.addView(Ui.label(a, "پلتفرم")); pfBox.addView(s2); pfv[0] = s2; });
    c.addView(pay, top(a, 8));
    final EditText cd = Fx.input(a, "۱۶ رقم", InputType.TYPE_CLASS_NUMBER); cd.setBackground(Ui.rr(a, Ui.NAVY, 14, 0xFF5A4720, 1));
    TextView wt = Ui.select(a, "کارت بانکی", new String[]{"کارت بانکی", "کیف پول"}, i -> toWallet[0] = i == 1); wt.setText("کارت بانکی"); wt.setTextColor(Fx.TX);
    LinearLayout wBox = Fx.vbox(a); wBox.addView(Ui.label(a, "دریافت مبلغ در")); wBox.addView(wt);
    LinearLayout cBox = Fx.vbox(a); cBox.addView(Ui.label(a, "شماره کارت")); cBox.addView(cd);
    c.addView(Ui.two(a, wBox, cBox), top(a, 4));
    c.addView(Ui.label(a, "اسکرین‌شات انتقال"));
    final String[] shot = {null};
    final TextView fb = Fx.text(a, "انتخاب فایل   |   فایلی انتخاب نشده است", 14, Fx.MU); fb.setBackground(Ui.rr(a, Ui.NAVY, 14, 0xFF5A4720, 1)); int d = Fx.dp(a, 16); fb.setPadding(d, d, d, d);
    fb.setOnClickListener(v -> a.pickImage(img -> { shot[0] = img; fb.setText("✓ عکس انتخاب شد"); fb.setTextColor(Fx.OK); })); c.addView(fb);
    final TextView msg = Fx.text(a, "", 14, Fx.BAD); c.addView(msg, top(a, 8));
    c.addView(Fx.button(a, "ثبت درخواست فروش", v -> {
      String q = faDigits(am.getText().toString().trim()); String card = faDigits(cd.getText().toString().replaceAll("[\\s-]", ""));
      if (plat[0].isEmpty()) { msg.setText("پلتفرم را انتخاب کنید."); msg.setTextColor(Fx.BAD); return; }
      if (q.isEmpty()) { msg.setText("تعداد سکه را وارد کنید."); msg.setTextColor(Fx.BAD); return; }
      if (!toWallet[0] && card.length() != 16) { msg.setText("شماره کارت باید ۱۶ رقم باشد."); msg.setTextColor(Fx.BAD); return; }
      if (shot[0] == null) { msg.setText("اسکرین‌شات انتقال را انتخاب کنید."); msg.setTextColor(Fx.BAD); return; }
      msg.setText("در حال ارسال…"); msg.setTextColor(Fx.MU);
      JSONObject b = Api.obj("coin", plat[0], "qty", Double.parseDouble(q), "dest", toWallet[0] ? "wallet" : "card", "screenshot", shot[0]);
      try { if (!toWallet[0]) b.put("card", card); } catch (Exception ex) { }
      Api.post("/api/orders", b, (r, e) -> { if (e != null) { msg.setText(e); msg.setTextColor(Fx.BAD); return; }
        msg.setText("✅ درخواست شما ثبت شد و در حال بررسی است. کد پیگیری: " + r.optString("code")); msg.setTextColor(Fx.OK); am.setText(""); shot[0] = null; fb.setText("انتخاب فایل   |   فایلی انتخاب نشده است"); fb.setTextColor(Fx.MU); });
    }), top(a, 12));
    c.addView(Fx.text(a, "بعد از ثبت، درخواست شما مستقیم برای ما ارسال می‌شود.", 14, Fx.MU), top(a, 10));
    box.addView(statsCard(a), top(a, 14)); return scroller(a, box);
  }
  // ---------- سفارشات ----------
  static View ordersBody(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); box.addView(Fx.text(a, "در حال بارگذاری…", 14, Fx.MU));
    Api.get("/api/orders/mine", (r, e) -> { box.removeAllViews(); JSONArray o = r == null ? null : r.optJSONArray("orders");
      if (o == null || o.length() == 0) { box.addView(Fx.text(a, e != null ? e : "هنوز سفارشی ثبت نکرده‌اید.", 16, Fx.MU)); return; }
      for (int i = 0; i < o.length(); i++) { JSONObject x = o.optJSONObject(i); LinearLayout c = Fx.card(a);
        c.addView(Fx.text(a, Fx.num(x.optLong("qty")) + " سکه " + x.optString("coin_name") + " — " + ("sell".equals(x.optString("kind")) ? "فروش" : "خرید"), 16, Fx.GOLD2));
        String st = x.optString("status"); String lb = "review".equals(st) ? "⏳ در حال بررسی" : "confirmed".equals(st) ? "✅ تایید شد" : "rejected".equals(st) ? "❌ رد شد" : "cancelled".equals(st) ? "🚫 لغو شد" : st;
        c.addView(Fx.text(a, lb, 14, Fx.TX), Fx.lp(a, Fx.WRAP, Fx.WRAP, 6)); c.addView(Fx.text(a, "کد پیگیری: " + x.optString("code"), 13, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 4));
        String note = x.optString("note"); if (!TextUtils.isEmpty(note)) c.addView(Fx.text(a, "توضیح: " + note, 13, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 4));
        box.addView(c, top(a, i == 0 ? 0 : 10)); } });
    return scroller(a, box);
  }
  static View annBody(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a);
    final LinearLayout empty = Fx.card(a); empty.addView(Fx.text(a, "اعلان تازه‌ای نیست.", 17, Fx.MU)); box.addView(empty);
    Api.get("/api/announcements", (r, e) -> { JSONArray an = r == null ? null : r.optJSONArray("announcements"); if (an == null || an.length() == 0) return; box.removeAllViews();
      for (int i = 0; i < an.length(); i++) { JSONObject x = an.optJSONObject(i); LinearLayout c = Fx.card(a); c.addView(Fx.text(a, x.optString("title"), 17, Fx.GOLD2));
        if (!TextUtils.isEmpty(x.optString("body"))) c.addView(Fx.text(a, x.optString("body"), 14, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 6)); box.addView(c, top(a, i == 0 ? 0 : 10)); } });
    return scroller(a, box);
  }
  // ---------- حساب ----------
  static View account(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); box.addView(Ui.title(a, "👤 حساب کاربری"));
    final LinearLayout pc = Fx.card(a); pc.setGravity(Gravity.CENTER_HORIZONTAL); box.addView(pc);
    final FrameLayout av = new FrameLayout(a); final TextView avi = Fx.text(a, "👤", 46, 0xFF1E6FD9); avi.setGravity(Gravity.CENTER);
    GradientDrawable ag = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFFF1D98C, 0xFFC9962E}); ag.setShape(GradientDrawable.OVAL); avi.setBackground(ag);
    final ImageView avImg = new ImageView(a); avImg.setScaleType(ImageView.ScaleType.CENTER_CROP); avImg.setOutlineProvider(new android.view.ViewOutlineProvider() { public void getOutline(View x, android.graphics.Outline o) { o.setOval(0, 0, x.getWidth(), x.getHeight()); } }); avImg.setClipToOutline(true); avImg.setVisibility(View.GONE);
    av.addView(avi, new FrameLayout.LayoutParams(Fx.dp(a, 100), Fx.dp(a, 100))); av.addView(avImg, new FrameLayout.LayoutParams(Fx.dp(a, 100), Fx.dp(a, 100)));
    TextView cam = Fx.text(a, "📷", 15, 0xFFFFFFFF); cam.setGravity(Gravity.CENTER); GradientDrawable cg = new GradientDrawable(); cg.setShape(GradientDrawable.OVAL); cg.setColor(0xFF14B8A6); cg.setStroke(Fx.dp(a, 2), 0xFF0A0618); cam.setBackground(cg);
    av.addView(cam, new FrameLayout.LayoutParams(Fx.dp(a, 34), Fx.dp(a, 34), Gravity.BOTTOM | Gravity.LEFT));
    av.setOnClickListener(v -> a.pickImage(img -> Api.put("/api/me", Api.obj("avatar", img), (r, e) -> { if (e != null) { Fx.toast(a, e); return; } showAvatar(avImg, img); })));
    pc.addView(av, new LinearLayout.LayoutParams(Fx.dp(a, 100), Fx.dp(a, 100)));
    final TextView un = Fx.text(a, "", 22, Fx.TX); un.setTypeface(Typeface.DEFAULT_BOLD); pc.addView(un, Fx.lp(a, Fx.WRAP, Fx.WRAP, 10));
    final TextView ph = Fx.text(a, "", 15, Fx.MU); ph.setLayoutDirection(View.LAYOUT_DIRECTION_LTR); pc.addView(ph, Fx.lp(a, Fx.WRAP, Fx.WRAP, 2));
    final LinearLayout form = Fx.vbox(a); form.setVisibility(View.GONE);
    final EditText fu = Fx.input(a, "نام کاربری", InputType.TYPE_CLASS_TEXT), fp = Fx.input(a, "09123456789", InputType.TYPE_CLASS_PHONE), fc = Fx.input(a, "شماره کارت ۱۶ رقم", InputType.TYPE_CLASS_NUMBER), fn = Fx.input(a, "رمز عبور جدید (اختیاری)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD), fo = Fx.input(a, "رمز عبور فعلی", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
    form.addView(fu, top(a, 8)); form.addView(fp, top(a, 8)); form.addView(fc, top(a, 8)); form.addView(fn, top(a, 8)); form.addView(fo, top(a, 8));
    final TextView pm = Fx.text(a, "", 14, Fx.BAD);
    form.addView(Fx.button(a, "💾 ذخیره‌ی اطلاعات", v -> { JSONObject b = Api.obj("username", fu.getText().toString().trim(), "phone", fp.getText().toString().trim(), "card", faDigits(fc.getText().toString().trim()));
      try { if (fn.getText().length() > 0) { b.put("new_password", fn.getText().toString()); b.put("password", fo.getText().toString()); } } catch (Exception ex) { }
      Api.put("/api/me", b, (r, e) -> { if (e != null) { pm.setText(e); pm.setTextColor(Fx.BAD); return; } pm.setText("اطلاعات ذخیره شد ✅"); pm.setTextColor(Fx.OK); JSONObject u = r.optJSONObject("user"); if (u != null) { un.setText(u.optString("username")); ph.setText(u.optString("phone")); } }); }), top(a, 12));
    form.addView(pm, top(a, 6));
    pc.addView(Fx.button(a, "✏️ ویرایش اطلاعات", v -> form.setVisibility(form.getVisibility() == View.GONE ? View.VISIBLE : View.GONE)), top(a, 14)); pc.addView(form, top(a, 0));
    Api.get("/api/me", (r, e) -> { JSONObject u = r == null ? null : r.optJSONObject("user"); if (u == null) return; un.setText(u.optString("username")); ph.setText(u.optString("phone")); fu.setText(u.optString("username")); fp.setText(u.optString("phone")); fc.setText(u.optString("card"));
      String av2 = u.optString("avatar"); if (av2.startsWith("data:")) showAvatar(avImg, av2); });
    // کیف پول
    LinearLayout wc = new LinearLayout(a); wc.setOrientation(LinearLayout.VERTICAL); wc.setBackground(Ui.goldBg(a, 28)); wc.setPadding(Fx.dp(a, 18), Fx.dp(a, 16), Fx.dp(a, 18), Fx.dp(a, 18));
    LinearLayout wh = Fx.hbox(a); TextView wt = Fx.text(a, "💰 کیف پول من", 18, 0xFF211604); wt.setTypeface(Typeface.DEFAULT_BOLD); wh.addView(wt, new LinearLayout.LayoutParams(0, Fx.WRAP, 1f));
    TextView tm = Fx.text(a, "تومان", 13, 0xFF6B4F12); tm.setBackground(Ui.rr(a, 0xAAFFF6D8, 20, 0, 0)); tm.setPadding(Fx.dp(a, 14), Fx.dp(a, 6), Fx.dp(a, 14), Fx.dp(a, 6)); wh.addView(tm); wc.addView(wh);
    final TextView bal = Fx.text(a, "۰", 42, 0xFF211604); bal.setTypeface(Typeface.DEFAULT_BOLD); bal.setGravity(Gravity.CENTER); wc.addView(bal, Fx.lp(a, Fx.MATCH, Fx.WRAP, 14));
    final TextView pt = Fx.text(a, "۰", 20, 0xFF211604), pw = Fx.text(a, "۰", 20, 0xFF211604); LinearLayout sr = Fx.hbox(a);
    for (int i = 0; i < 2; i++) { LinearLayout b = Fx.vbox(a); b.setBackground(Ui.rr(a, 0xAAFFF6D8, 18, 0, 0)); b.setPadding(Fx.dp(a, 12), Fx.dp(a, 10), Fx.dp(a, 12), Fx.dp(a, 10)); b.addView(Fx.text(a, i == 0 ? "افزایش در انتظار تایید" : "برداشت در انتظار", 13, 0xFF6B4F12)); b.addView(i == 0 ? pt : pw, Fx.lp(a, Fx.WRAP, Fx.WRAP, 4));
      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Fx.WRAP, 1f); lp.setMargins(Fx.dp(a, 4), 0, Fx.dp(a, 4), 0); sr.addView(b, lp); }
    wc.addView(sr, Fx.lp(a, Fx.MATCH, Fx.WRAP, 12)); box.addView(wc, top(a, 14));
    final LinearLayout panel = Ui.navy(a); panel.setVisibility(View.GONE);
    final LinearLayout wl = Fx.vbox(a); wl.addView(Fx.text(a, "هنوز واریزی‌ای ندارید.", 15, Fx.MU));
    LinearLayout wb = Ui.two(a, Fx.button(a, "➕ افزایش موجودی", v -> walletPanel(a, panel, true)), Fx.button(a, "➖ برداشت", v -> walletPanel(a, panel, false))); box.addView(wb, top(a, 14)); box.addView(panel, top(a, 12));
    LinearLayout dc = Fx.card(a); dc.addView(Fx.gold(a, "📥 واریزی‌ها به کیف پول", 18)); dc.addView(wl, top(a, 10)); box.addView(dc, top(a, 14));
    Api.get("/api/wallet", (r, e) -> { if (r == null) return; WAL = r; bal.setText(Fx.num(r.optLong("balance"))); pt.setText(Fx.num(r.optLong("pending_topup"))); pw.setText(Fx.num(r.optLong("pending_withdraw")));
      JSONArray tx = r.optJSONArray("tx"); wl.removeAllViews(); int shown = 0;
      if (tx != null) for (int i = 0; i < tx.length(); i++) { JSONObject t = tx.optJSONObject(i); String k = t.optString("kind"); if (!(k.equals("topup") || k.equals("sell_credit") || k.equals("withdraw"))) continue; if ("cancelled".equals(t.optString("status"))) continue; shown++;
        String lb = k.equals("topup") ? "➕ افزایش موجودی" : k.equals("withdraw") ? "➖ برداشت" : "📥 فروش سکه به کیف پول"; String st = t.optString("status"); String sl = "pending".equals(st) ? "⏳ در انتظار تایید" : "confirmed".equals(st) ? "✅ تایید شد" : "rejected".equals(st) ? "❌ رد شد" : st;
        wl.addView(Fx.text(a, lb + " — " + Fx.num(t.optLong("amount")) + " ت", 15, Fx.TX), Fx.lp(a, Fx.WRAP, Fx.WRAP, 10)); wl.addView(Fx.text(a, sl, 13, Fx.MU)); }
      if (shown == 0) wl.addView(Fx.text(a, "هنوز واریزی‌ای ندارید.", 15, Fx.MU)); });
    LinearLayout sc2 = Fx.card(a); sc2.addView(statsCard(a)); sc2.addView(Fx.button(a, "📋 سفارشات من", v -> a.push(page("📋 سفارشات", UserActivity::ordersBody))), top(a, 14));
    sc2.addView(Fx.button(a, "خروج از حساب", v -> Fx.confirm(a, "از حساب خارج می‌شوید؟", () -> { Session.clear(); a.replaceAll(new Auth.Login(NEXT, false)); })), top(a, 12)); box.addView(sc2, top(a, 14));
    return scroller(a, box);
  }
  static void showAvatar(ImageView iv, String dataUrl) {
    try { String b64 = dataUrl.substring(dataUrl.indexOf(',') + 1); byte[] bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT); Bitmap bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.length); if (bm != null) { iv.setImageBitmap(bm); iv.setVisibility(View.VISIBLE); } } catch (Exception e) { }
  }
  static void walletPanel(final BaseActivity a, final LinearLayout p, final boolean topup) {
    p.removeAllViews(); p.setVisibility(View.VISIBLE); p.addView(Fx.gold(a, topup ? "➕ افزایش موجودی" : "➖ برداشت از کیف پول", 18));
    JSONObject s = CFG.optJSONObject("settings"); String oc = s == null ? "" : s.optString("owner_card");
    if (topup) p.addView(Fx.text(a, TextUtils.isEmpty(oc) ? "شماره کارت هنوز تنظیم نشده است؛ با پشتیبانی تماس بگیرید." : "مبلغ دلخواه را وارد کنید و دقیقاً همان مبلغ را به این شماره کارت واریز کنید:\n" + oc, 14, Fx.MU), top(a, 8));
    else p.addView(Fx.text(a, "موجودی قابل برداشت: " + Fx.num(WAL.optLong("balance")) + " تومان", 14, Fx.MU), top(a, 8));
    final EditText am = Fx.input(a, "مبلغ (تومان)", InputType.TYPE_CLASS_NUMBER); p.addView(am, top(a, 10));
    final EditText cd = Fx.input(a, "شماره کارت ۱۶ رقم", InputType.TYPE_CLASS_NUMBER); if (!topup) p.addView(cd, top(a, 8));
    final String[] shot = {null}; final TextView fb = Fx.text(a, "انتخاب اسکرین‌شات واریز", 14, Fx.MU); fb.setBackground(Ui.rr(a, 0xFF0A0618, 14, 0xFF5A4720, 1)); int d = Fx.dp(a, 14); fb.setPadding(d, d, d, d);
    fb.setOnClickListener(v -> a.pickImage(img -> { shot[0] = img; fb.setText("✓ عکس انتخاب شد"); fb.setTextColor(Fx.OK); })); if (topup) p.addView(fb, top(a, 8));
    final TextView msg = Fx.text(a, "", 14, Fx.BAD);
    p.addView(Fx.button(a, topup ? "ثبت درخواست افزایش" : "ثبت درخواست برداشت", v -> { long amt = num(faDigits(am.getText().toString().trim())); if (amt <= 0) { msg.setText("مبلغ را درست وارد کنید."); msg.setTextColor(Fx.BAD); return; }
      JSONObject b = Api.obj("amount", amt);
      try { if (topup) { if (shot[0] == null) { msg.setText("اسکرین‌شات واریز را انتخاب کنید."); msg.setTextColor(Fx.BAD); return; } b.put("screenshot", shot[0]); } else { String c = faDigits(cd.getText().toString().replaceAll("[\\s-]", "")); if (c.length() != 16) { msg.setText("شماره کارت باید ۱۶ رقم باشد."); msg.setTextColor(Fx.BAD); return; } b.put("card", c); } } catch (Exception ex) { }
      Api.post(topup ? "/api/wallet/topup" : "/api/wallet/withdraw", b, (r, e) -> { if (e != null) { msg.setText(e); msg.setTextColor(Fx.BAD); return; } msg.setText("✅ درخواست شما ثبت شد و در حال بررسی است."); msg.setTextColor(Fx.OK); am.setText(""); }); }), top(a, 12));
    p.addView(msg, top(a, 8));
  }
  // ---------- بیشتر ----------
  static View tile(final BaseActivity a, String emoji, String label, View.OnClickListener l) {
    LinearLayout t = Ui.navy(a); t.setGravity(Gravity.CENTER_HORIZONTAL); t.setPadding(Fx.dp(a, 10), Fx.dp(a, 22), Fx.dp(a, 10), Fx.dp(a, 22));
    t.addView(Ui.hex(a, emoji, 84)); TextView x = Fx.text(a, label, 17, Fx.TX); t.addView(x, Fx.lp(a, Fx.WRAP, Fx.WRAP, 14)); t.setOnClickListener(l); return t;
  }
  static View more(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); box.addView(Ui.title(a, "☰ بیشتر"));
    box.addView(tile(a, "💬", "پشتیبانی", v -> Ui.openUrl(a, "https://ble.ir/postibani")), top(a, 0));
    final LinearLayout cmt = Ui.navy(a); cmt.setVisibility(View.GONE); final LinearLayout del = Ui.navy(a); del.setVisibility(View.GONE);
    View t1 = tile(a, "💭", "ارسال نظر", v -> { cmt.setVisibility(View.VISIBLE); del.setVisibility(View.GONE); });
    View t2 = tile(a, "❓", "سؤالات متداول", v -> TabsScreen.last.goTo(2));
    box.addView(Ui.two(a, t2, t1), top(a, 12));
    View t3 = tile(a, "🗑️", "حذف حساب", v -> { del.setVisibility(View.VISIBLE); cmt.setVisibility(View.GONE); });
    View t4 = tile(a, "🚪", "خروج از حساب", v -> Fx.confirm(a, "از حساب خارج می‌شوید؟", () -> { Session.clear(); a.replaceAll(new Auth.Login(NEXT, false)); }));
    box.addView(Ui.two(a, t4, t3), top(a, 12));
    cmt.addView(Fx.gold(a, "💭 نظر شما", 18)); cmt.addView(Fx.text(a, "نظر یا پیشنهادتان را بنویسید تا برای ما بفرستید.", 14, Fx.MU), top(a, 6));
    final EditText nt = Fx.input(a, "نظر شما...", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE); nt.setSingleLine(false); nt.setMinLines(3); cmt.addView(nt, top(a, 10));
    final TextView cm = Fx.text(a, "", 14, Fx.BAD);
    cmt.addView(Fx.button(a, "ارسال نظر", v -> { String t = nt.getText().toString().trim(); if (t.isEmpty()) return; Api.post("/api/comments", Api.obj("text", t), (r, e) -> { if (e != null) { cm.setText(e); cm.setTextColor(Fx.BAD); return; } cm.setText("✅ نظر شما ارسال شد."); cm.setTextColor(Fx.OK); nt.setText(""); }); }), top(a, 10)); cmt.addView(cm, top(a, 6));
    del.addView(Fx.gold(a, "🗑️ حذف حساب", 18)); del.addView(Fx.text(a, "با حذف حساب، اطلاعات شما پاک می‌شود و قابل بازگشت نیست.", 14, Fx.MU), top(a, 6));
    final EditText dp = Fx.input(a, "رمز عبور برای تایید", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD); del.addView(dp, top(a, 10)); final TextView dm = Fx.text(a, "", 14, Fx.BAD);
    TextView db = Fx.button(a, "حذف دائمی حساب", v -> Fx.confirm(a, "حساب برای همیشه حذف شود؟", () -> Api.delete("/api/me", Api.obj("password", dp.getText().toString()), (r, e) -> { if (e != null) { dm.setText(e); return; } Session.clear(); a.replaceAll(new Auth.Login(NEXT, false)); })));
    del.addView(db, top(a, 10)); del.addView(dm, top(a, 6));
    box.addView(cmt, top(a, 14)); box.addView(del, top(a, 14)); return scroller(a, box);
  }
  // ---------- دستیار هوشمند ----------
  static class AiScreen extends Screen {
    LinearLayout box; ScrollView sv; boolean started = false, busy = false; JSONArray hist = new JSONArray(); EditText inp;
    public View create() {
      final BaseActivity a = act; LinearLayout c = Fx.vbox(a); c.setBackgroundColor(0xF2100D08);
      LinearLayout h = Fx.hbox(a); h.setPadding(Fx.dp(a, 16), Fx.dp(a, 14), Fx.dp(a, 16), Fx.dp(a, 10));
      TextView br = Fx.gold(a, "✦ سکه چنده", 20); h.addView(br); TextView tg = Fx.text(a, "   دستیار هوشمند", 14, Fx.MU); h.addView(tg, new LinearLayout.LayoutParams(0, Fx.WRAP, 1f)); h.addView(Ui.pill(a, "✕", v -> a.pop())); c.addView(h);
      box = Fx.vbox(a); box.setPadding(Fx.dp(a, 14), Fx.dp(a, 6), Fx.dp(a, 14), Fx.dp(a, 14)); sv = new ScrollView(a); sv.addView(box); c.addView(sv, new LinearLayout.LayoutParams(Fx.MATCH, 0, 1f));
      LinearLayout bar = Fx.hbox(a); bar.setPadding(Fx.dp(a, 12), Fx.dp(a, 8), Fx.dp(a, 12), Fx.dp(a, 12));
      TextView send = Fx.text(a, "➤", 22, 0xFF1B1405); send.setGravity(Gravity.CENTER); send.setBackground(Ui.goldBg(a, 30)); send.setOnClickListener(v -> ask(inp.getText().toString()));
      inp = Fx.input(a, "سوال بپرس ...", InputType.TYPE_CLASS_TEXT); inp.setBackground(Ui.rr(a, 0x33FFFFFF, 18, 0xFF5A4720, 1));
      bar.addView(send, new LinearLayout.LayoutParams(Fx.dp(a, 52), Fx.dp(a, 52))); LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, Fx.WRAP, 1f); ip.setMarginStart(Fx.dp(a, 8)); bar.addView(inp, ip); c.addView(bar);
      showStart(); return c;
    }
    void showStart() {
      final BaseActivity a = act; box.removeAllViews();
      box.addView(Ui.img(a, "robot", -1, 340, true), new LinearLayout.LayoutParams(Fx.MATCH, Fx.dp(a, 340)));
      TextView sg = Fx.gold(a, "شروع گفتگو ‹", 18); sg.setGravity(Gravity.CENTER); sg.setOnClickListener(v -> begin()); box.addView(sg, top(a, 14));
      TextView q = Fx.text(a, "سلام، چطور می‌تونم کمکت کنم؟", 20, Fx.GOLD2); q.setGravity(Gravity.CENTER); box.addView(q, top(a, 22));
      ImageView orn = Ui.img(a, "ornament", 260, 220, false); LinearLayout.LayoutParams op = (LinearLayout.LayoutParams) orn.getLayoutParams(); op.gravity = Gravity.CENTER_HORIZONTAL; op.topMargin = Fx.dp(a, 12); box.addView(orn, op);
      final String[] qs = {"چطور سکه بفروشم؟", "قیمت امروز سکه‌ها چقدره؟", "خرید سکه کی باز می‌شود؟", "سفارشم چطور بررسی می‌شود؟"};
      LinearLayout r1 = Fx.hbox(a), r2 = Fx.hbox(a);
      r1.addView(Ui.two(a, sug(qs[0]), sug(qs[1])), new LinearLayout.LayoutParams(Fx.MATCH, Fx.WRAP)); r2.addView(Ui.two(a, sug(qs[2]), sug(qs[3])), new LinearLayout.LayoutParams(Fx.MATCH, Fx.WRAP));
      box.addView(r1, top(a, 18)); box.addView(r2, top(a, 12));
    }
    View sug(final String q) { TextView t = Fx.text(act, q, 15, 0xFFF0DFB5); t.setGravity(Gravity.CENTER); t.setBackground(Ui.rr(act, 0x22D6B35B, 18, 0x44E2C277, 1)); int d = Fx.dp(act, 14); t.setPadding(d, Fx.dp(act, 22), d, Fx.dp(act, 22)); t.setMinHeight(Fx.dp(act, 96)); t.setOnClickListener(v -> ask(q)); return t; }
    void begin() { if (started) return; started = true; box.removeAllViews(); bubble("سلام! من راهنمای هوشمند سکه چنده‌ام. درباره‌ی خرید و فروش سکه، ثبت‌نام، حساب کاربری، کیف پول، سفارش‌ها و کار با سایت هر سؤالی داری بپرس.", false); }
    TextView bubble(String t, boolean user) {
      TextView b = Fx.text(act, t, 16, Fx.TX); b.setLineSpacing(Fx.dp(act, 6), 1f); int d = Fx.dp(act, 16); b.setPadding(d, d, d, d);
      b.setBackground(Ui.rr(act, user ? 0xFF3A2D12 : 0xFF17120A, 22, 0xFF5A4720, 1));
      LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Fx.WRAP, Fx.WRAP); p.topMargin = Fx.dp(act, 12); p.gravity = user ? Gravity.END : Gravity.START; box.addView(b, p);
      sv.post(() -> sv.fullScroll(View.FOCUS_DOWN)); return b;
    }
    void ask(String q0) {
      final String q = q0 == null ? "" : q0.trim(); if (busy || q.isEmpty()) return; busy = true; begin(); bubble(q, true); inp.setText("");
      final TextView out = bubble("در حال یافتن پاسخ…", false);
      JSONObject b = Api.obj("q", q, "hist", hist, "site", "");
      Api.post("/api/ai", b, (r, e) -> { busy = false; String ans = "";
        if (r != null) for (String k : new String[]{"a", "answer", "text", "reply", "message"}) { if (!TextUtils.isEmpty(r.optString(k))) { ans = r.optString(k); break; } }
        if (ans.isEmpty()) ans = e != null ? e : "پاسخی دریافت نشد. دوباره تلاش کنید.";
        out.setText(ans); try { hist.put(Api.obj("role", "user", "content", q)); hist.put(Api.obj("role", "assistant", "content", ans)); } catch (Exception ex) { } sv.post(() -> sv.fullScroll(View.FOCUS_DOWN)); });
    }
  }
}
