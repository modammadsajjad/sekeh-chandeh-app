package com.sekehchandeh.core;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
public class Fx {
  public static final int BG = 0xFF07060A, CARD1 = 0xFF1D170C, CARD2 = 0xFF0C0904, LINE = 0xFF5A4720;
  public static final int GOLD = 0xFFE7B94F, GOLD2 = 0xFFF7DF91, GOLD3 = 0xFF9B7421;
  public static final int TX = 0xFFFFF8E8, MU = 0xFFC5B58E, OK = 0xFF3DDC97, BAD = 0xFFFF7A9C;
  public static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
  public interface FormCb { void ok(String[] v); }
  public static int dp(Context c, float v) { return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f); }
  public static LinearLayout.LayoutParams lp(Context c, int w, int h, float top) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h); p.topMargin = dp(c, top); return p; }
  public static LinearLayout.LayoutParams wt(Context c, float w, float top) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, WRAP, w); p.topMargin = dp(c, top); p.setMarginStart(dp(c, 4)); p.setMarginEnd(dp(c, 4)); return p; }
  public static LinearLayout vbox(Context c) { LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL); return l; }
  public static LinearLayout hbox(Context c) { LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
  public static TextView text(Context c, String s, float sp, int color) { TextView t = new TextView(c); t.setText(s); t.setTextSize(sp); t.setTextColor(color); return t; }
  public static TextView gold(Context c, String s, float sp) {
    TextView t = text(c, s, sp, GOLD); t.setTypeface(Typeface.DEFAULT_BOLD);
    t.getPaint().setShader(new LinearGradient(0, 0, 0, dp(c, sp * 1.4f), new int[]{GOLD2, GOLD, GOLD3}, null, Shader.TileMode.CLAMP));
    t.setShadowLayer(dp(c, 3), 0, dp(c, 2), 0xAA000000);
    return t;
  }
  public static Drawable cardBg(Context c, float r) {
    GradientDrawable lip = new GradientDrawable(); lip.setColor(0xFF000000); lip.setCornerRadius(dp(c, r));
    GradientDrawable face = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{CARD1, CARD2});
    face.setCornerRadius(dp(c, r)); face.setStroke(dp(c, 1), LINE);
    LayerDrawable ld = new LayerDrawable(new Drawable[]{lip, face}); ld.setLayerInset(1, 0, 0, 0, dp(c, 3));
    return ld;
  }
  public static LinearLayout card(Context c) { LinearLayout l = vbox(c); l.setBackground(cardBg(c, 18)); int p = dp(c, 14); l.setPadding(p, p, p, p + dp(c, 3)); return l; }
  private static void press(final View v) {
    final float d = dp(v.getContext(), 2);
    v.setOnTouchListener(new View.OnTouchListener() { public boolean onTouch(View x, MotionEvent e) {
      int a = e.getAction();
      if (a == MotionEvent.ACTION_DOWN) x.setTranslationY(d); else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) x.setTranslationY(0);
      return false; } });
  }
  public static TextView button(Context c, String s, View.OnClickListener l) {
    TextView b = text(c, s, 16, 0xFF1B1405); b.setGravity(Gravity.CENTER); b.setTypeface(Typeface.DEFAULT_BOLD);
    int r = dp(c, 14);
    GradientDrawable rim = new GradientDrawable(); rim.setColor(0xFF6B4F12); rim.setCornerRadius(r);
    GradientDrawable face = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{GOLD2, GOLD, GOLD3}); face.setCornerRadius(r); face.setStroke(dp(c, 1), 0xFFFFE9A8);
    LayerDrawable ld = new LayerDrawable(new Drawable[]{rim, face}); ld.setLayerInset(1, 0, 0, 0, dp(c, 4));
    b.setBackground(ld); b.setPadding(dp(c, 18), dp(c, 12), dp(c, 18), dp(c, 16)); b.setOnClickListener(l); press(b);
    return b;
  }
  public static TextView ghost(Context c, String s, View.OnClickListener l) {
    TextView b = text(c, s, 15, GOLD); b.setGravity(Gravity.CENTER);
    GradientDrawable g = new GradientDrawable(); g.setColor(0x22000000); g.setCornerRadius(dp(c, 14)); g.setStroke(dp(c, 1), GOLD3);
    b.setBackground(g); b.setPadding(dp(c, 18), dp(c, 12), dp(c, 18), dp(c, 12)); b.setOnClickListener(l); press(b);
    return b;
  }
  public static TextView chip(Context c, String s, boolean on, View.OnClickListener l) {
    TextView b = text(c, s, 13, on ? 0xFF1B1405 : MU); b.setGravity(Gravity.CENTER);
    GradientDrawable g = on ? new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{GOLD2, GOLD}) : new GradientDrawable();
    if (!on) g.setColor(0x22000000);
    g.setCornerRadius(dp(c, 20)); g.setStroke(dp(c, 1), on ? 0xFFFFE9A8 : LINE);
    b.setBackground(g); b.setPadding(dp(c, 16), dp(c, 6), dp(c, 16), dp(c, 6)); b.setOnClickListener(l);
    return b;
  }
  public static EditText input(Context c, String hint, int type) {
    EditText e = new EditText(c); e.setHint(hint); e.setHintTextColor(0xFF7C7157); e.setTextColor(TX); e.setTextSize(15); e.setInputType(type); e.setSingleLine(true);
    GradientDrawable g = new GradientDrawable(); g.setColor(0xFF0B0805); g.setCornerRadius(dp(c, 12)); g.setStroke(dp(c, 1), LINE);
    e.setBackground(g); e.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12)); e.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
    return e;
  }
  public static Dialog modal(Activity a, View content) {
    Dialog d = new Dialog(a); d.requestWindowFeature(Window.FEATURE_NO_TITLE);
    content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); d.setContentView(content);
    Window w = d.getWindow(); w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    w.setLayout((int) (a.getResources().getDisplayMetrics().widthPixels * 0.92f), WRAP);
    d.show(); return d;
  }
  public static void form(final Activity a, String title, String[] hints, String[] init, int[] types, String okText, final FormCb cb) {
    LinearLayout box = card(a); box.addView(gold(a, title, 18));
    final EditText[] es = new EditText[hints.length];
    for (int i = 0; i < hints.length; i++) { es[i] = input(a, hints[i], types[i]); if (init != null && init[i] != null) es[i].setText(init[i]); box.addView(es[i], lp(a, MATCH, WRAP, 10)); }
    final Dialog[] dd = new Dialog[1];
    LinearLayout row = hbox(a);
    row.addView(button(a, okText, new View.OnClickListener() { public void onClick(View v) {
      String[] r = new String[es.length]; for (int i = 0; i < r.length; i++) r[i] = es[i].getText().toString().trim();
      dd[0].dismiss(); cb.ok(r); } }), wt(a, 1, 0));
    row.addView(ghost(a, "انصراف", new View.OnClickListener() { public void onClick(View v) { dd[0].dismiss(); } }), wt(a, 1, 0));
    box.addView(row, lp(a, MATCH, WRAP, 14));
    dd[0] = modal(a, box);
  }
  public static void confirm(final Activity a, String msg, final Runnable ok) {
    LinearLayout box = card(a); box.addView(text(a, msg, 15, TX));
    final Dialog[] dd = new Dialog[1];
    LinearLayout row = hbox(a);
    row.addView(button(a, "بله", new View.OnClickListener() { public void onClick(View v) { dd[0].dismiss(); ok.run(); } }), wt(a, 1, 0));
    row.addView(ghost(a, "خیر", new View.OnClickListener() { public void onClick(View v) { dd[0].dismiss(); } }), wt(a, 1, 0));
    box.addView(row, lp(a, MATCH, WRAP, 14)); dd[0] = modal(a, box);
  }
  public static void toast(Context c, String m) { Toast.makeText(c, m, Toast.LENGTH_LONG).show(); }
  public static String fa(String s) { StringBuilder b = new StringBuilder(); for (char ch : s.toCharArray()) b.append(ch >= '0' && ch <= '9' ? (char) ('۰' + (ch - '0')) : ch); return b.toString(); }
  public static String num(long n) {
    String s = String.valueOf(Math.abs(n)); StringBuilder b = new StringBuilder();
    for (int i = 0; i < s.length(); i++) { if (i > 0 && (s.length() - i) % 3 == 0) b.append('٬'); b.append(s.charAt(i)); }
    return (n < 0 ? "-" : "") + fa(b.toString());
  }
}
