package com.sekehchandeh.core;
import android.os.Handler;
import android.os.Looper;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
public class Api {
  public static final String BASE = "https://sekeh-chandeh-app.onrender.com";
  public interface Cb { void done(JSONObject r, String err); }
  private static final ExecutorService EXEC = Executors.newFixedThreadPool(4);
  private static final Handler MAIN = new Handler(Looper.getMainLooper());
  public static Runnable onAuthFail;
  private static JSONObject features = new JSONObject();
  public static void setFeatures(JSONObject f) { if (f != null) features = f; }
  public static boolean feature(String k) { return features.optBoolean(k, true); }
  public static JSONObject obj(Object... kv) {
    JSONObject o = new JSONObject();
    try { for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]); } catch (Exception e) { }
    return o;
  }
  public static void get(String p, Cb cb) { call("GET", p, null, cb); }
  public static void post(String p, JSONObject b, Cb cb) { call("POST", p, b, cb); }
  public static void put(String p, JSONObject b, Cb cb) { call("PUT", p, b, cb); }
  public static void delete(String p, JSONObject b, Cb cb) { call("DELETE", p, b, cb); }
  public static void delete(String p, Cb cb) { call("DELETE", p, null, cb); }
  private static String read(InputStream is) throws Exception {
    if (is == null) return "";
    ByteArrayOutputStream o = new ByteArrayOutputStream();
    byte[] b = new byte[8192]; int n;
    while ((n = is.read(b)) > 0) o.write(b, 0, n);
    is.close();
    return o.toString("UTF-8");
  }
  public interface ImgCb { void done(android.graphics.Bitmap b); }
  public static void image(final String p, final ImgCb cb) {
    EXEC.execute(new Runnable() { public void run() {
      android.graphics.Bitmap bm = null;
      try { HttpURLConnection c = (HttpURLConnection) new URL(BASE + p).openConnection(); c.setConnectTimeout(30000); c.setReadTimeout(60000);
        String t = Session.token(); if (t != null) c.setRequestProperty("Authorization", "Bearer " + t);
        if (c.getResponseCode() < 400) { InputStream is = c.getInputStream(); byte[] raw = readBytes(is); String txt = new String(raw, "UTF-8");
          int i = txt.indexOf("base64,"); if (txt.startsWith("data:") && i > 0) raw = android.util.Base64.decode(txt.substring(i + 7).trim(), android.util.Base64.DEFAULT);
          bm = android.graphics.BitmapFactory.decodeByteArray(raw, 0, raw.length); } } catch (Exception e) { }
      final android.graphics.Bitmap fb = bm; MAIN.post(new Runnable() { public void run() { cb.done(fb); } });
    } });
  }
  private static byte[] readBytes(InputStream is) throws Exception { ByteArrayOutputStream o = new ByteArrayOutputStream(); byte[] b = new byte[8192]; int n; while ((n = is.read(b)) > 0) o.write(b, 0, n); is.close(); return o.toByteArray(); }
  private static void call(final String m, final String p, final JSONObject body, final Cb cb) {
    EXEC.execute(new Runnable() { public void run() {
      JSONObject res = null; String err = "ارتباط با سرور برقرار نشد. اینترنت را بررسی کنید."; int code = 0;
      for (int attempt = 0; attempt < 3; attempt++) {
        try {
          HttpURLConnection c = (HttpURLConnection) new URL(BASE + p).openConnection();
          c.setRequestMethod(m); c.setConnectTimeout(30000); c.setReadTimeout(90000);
          c.setRequestProperty("Accept", "application/json");
          String t = Session.token();
          if (t != null) c.setRequestProperty("Authorization", "Bearer " + t);
          if (body != null) {
            c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            OutputStream os = c.getOutputStream(); os.write(body.toString().getBytes("UTF-8")); os.close();
          }
          code = c.getResponseCode();
          String txt = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
          if (code == 502 || code == 503 || code == 504) { Thread.sleep(5000); continue; }
          try { res = txt.isEmpty() ? new JSONObject() : new JSONObject(txt); } catch (Exception e) { res = null; }
          if (res == null) { err = "پاسخ نامعتبر از سرور (" + code + ")"; }
          else if (code >= 400) { err = res.optString("error", "خطا"); res = null; }
          else err = null;
          break;
        } catch (Exception e) { try { Thread.sleep(3000); } catch (Exception x) { } }
      }
      final JSONObject fr = res; final String fe = err; final int fc = code;
      MAIN.post(new Runnable() { public void run() {
        if (fc == 401 && Session.token() != null && onAuthFail != null) { onAuthFail.run(); return; }
        cb.done(fr, fe);
      } });
    } });
  }
}
