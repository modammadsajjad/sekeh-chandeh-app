package com.sekehchandeh.core;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import java.util.ArrayList;
public abstract class BaseActivity extends Activity {
  private FrameLayout host;
  private final ArrayList<Screen> stack = new ArrayList<Screen>();
  protected abstract void start();
  public interface PickCb { void got(String dataUrl); }
  private PickCb pcb;
  public void pickImage(PickCb cb) { pcb = cb; Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*"); startActivityForResult(i, 77); }
  @Override protected void onActivityResult(int rc, int res, Intent d) {
    super.onActivityResult(rc, res, d);
    if (rc == 77 && res == RESULT_OK && d != null && d.getData() != null && pcb != null) {
      try {
        InputStream is = getContentResolver().openInputStream(d.getData()); Bitmap b = BitmapFactory.decodeStream(is); is.close();
        int m = Math.max(b.getWidth(), b.getHeight()); if (m > 900) { float k = 900f / m; b = Bitmap.createScaledBitmap(b, Math.round(b.getWidth() * k), Math.round(b.getHeight() * k), true); }
        ByteArrayOutputStream o = new ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 70, o);
        pcb.got("data:image/jpeg;base64," + android.util.Base64.encodeToString(o.toByteArray(), android.util.Base64.NO_WRAP));
      } catch (Exception e) { Fx.toast(this, "خواندن عکس ممکن نشد."); }
    }
  }
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    Session.init(this);
    getWindow().setStatusBarColor(Fx.BG); getWindow().setNavigationBarColor(Fx.BG);
    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    FrameLayout root = new FrameLayout(this); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); root.setFitsSystemWindows(true);
    root.addView(new Stars(this), new FrameLayout.LayoutParams(Fx.MATCH, Fx.MATCH));
    host = new FrameLayout(this); root.addView(host, new FrameLayout.LayoutParams(Fx.MATCH, Fx.MATCH));
    setContentView(root);
    start();
  }
  private void show(Screen s) {
    s.act = this; View v = s.create(); host.removeAllViews(); host.addView(v, new FrameLayout.LayoutParams(Fx.MATCH, Fx.MATCH));
    v.setAlpha(0f); v.animate().alpha(1f).setDuration(220).start(); s.shown();
  }
  public void push(Screen s) { stack.add(s); show(s); }
  public void replaceAll(Screen s) { stack.clear(); push(s); }
  public void pop() { if (stack.size() < 2) { finish(); return; } stack.remove(stack.size() - 1); show(stack.get(stack.size() - 1)); }
  @Override public void onBackPressed() { pop(); }
}
