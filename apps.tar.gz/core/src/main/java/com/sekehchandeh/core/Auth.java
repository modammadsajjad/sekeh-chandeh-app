package com.sekehchandeh.core;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
public class Auth {
  public interface Next { Screen make(); }
  public static class Splash extends Screen {
    private final Next next; private final boolean adminOnly; private TextView st; private TextView retry;
    public Splash(Next n, boolean adminOnly) { next = n; this.adminOnly = adminOnly; }
    @Override public View create() {
      LinearLayout c = Fx.vbox(act); c.setGravity(Gravity.CENTER); c.setPadding(Fx.dp(act, 30), 0, Fx.dp(act, 30), 0);
      c.addView(Fx.logo(act, 150));
      c.addView(Fx.gold(act, adminOnly ? "مدیریت سکه چنده" : "سکه چنده", 28), Fx.lp(act, Fx.WRAP, Fx.WRAP, 14));
      st = Fx.text(act, "در حال اتصال به سرور…\nبار اول ممکن است تا یک دقیقه طول بکشد.", 13, Fx.MU); st.setGravity(Gravity.CENTER);
      c.addView(st, Fx.lp(act, Fx.WRAP, Fx.WRAP, 16));
      retry = Fx.button(act, "تلاش دوباره", new View.OnClickListener() { public void onClick(View v) { go(); } });
      retry.setVisibility(View.GONE); c.addView(retry, Fx.lp(act, Fx.WRAP, Fx.WRAP, 16));
      return c;
    }
    @Override public void shown() { go(); }
    private void fail(String e) { st.setText(e); st.setTextColor(Fx.BAD); retry.setVisibility(View.VISIBLE); }
    private void go() {
      retry.setVisibility(View.GONE); st.setTextColor(Fx.MU);
      Api.get("/api/features", new Api.Cb() { public void done(JSONObject r, String e) {
        if (e != null) { fail(e); return; }
        Api.setFeatures(r.optJSONObject("features"));
        if (Session.token() == null) { act.replaceAll(new Login(next, adminOnly)); return; }
        Api.get("/api/me", new Api.Cb() { public void done(JSONObject r2, String e2) {
          if (e2 != null) { fail(e2); return; }
          JSONObject u = r2.optJSONObject("user");
          if (adminOnly && (u == null || !"admin".equals(u.optString("role")))) { Session.clear(); act.replaceAll(new Login(next, true)); return; }
          act.replaceAll(next.make());
        } });
      } });
    }
  }
  public static class Login extends Screen {
    private final Next next; private final boolean adminOnly; private boolean reg = false; private LinearLayout box;
    public Login(Next n, boolean adminOnly) { next = n; this.adminOnly = adminOnly; }
    @Override public View create() {
      ScrollView sv = new ScrollView(act); LinearLayout c = Fx.vbox(act); c.setGravity(Gravity.CENTER_HORIZONTAL);
      c.setPadding(Fx.dp(act, 20), Fx.dp(act, 40), Fx.dp(act, 20), Fx.dp(act, 20)); sv.addView(c);
      c.addView(Fx.logo(act, 140));
      if (adminOnly) c.addView(Fx.gold(act, "مدیریت سکه چنده", 26), Fx.lp(act, Fx.WRAP, Fx.WRAP, 10)); else { ImageView bt = Ui.titleImg(act, "t_brand", 56); bt.setScaleType(ImageView.ScaleType.FIT_CENTER); c.addView(bt, Fx.lp(act, Fx.WRAP, Fx.dp(act, 56), 10)); }
      LinearLayout bn = Ui.navy(act); bn.setBackground(Ui.rr(act, 0xFF2A1F0A, 22, 0xFF8C682C, 1));
      TextView b1 = Fx.text(act, adminOnly ? "پنل مدیریت سکه چنده" : "ورود به سکه چنده", 18, Fx.GOLD2); b1.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); bn.addView(b1);
      bn.addView(Fx.text(act, adminOnly ? "ورود فقط برای مدیر سایت" : "خرید و فروش سریع و امن سکه", 14, Fx.MU), Fx.lp(act, Fx.WRAP, Fx.WRAP, 4));
      c.addView(bn, Fx.lp(act, Fx.MATCH, Fx.WRAP, 18));
      box = Ui.navy(act); c.addView(box, Fx.lp(act, Fx.MATCH, Fx.WRAP, 14));
      render();
      return sv;
    }
    private View fld(String emoji, String label, final EditText e, boolean eye) {
      LinearLayout w = Fx.vbox(act); w.addView(Ui.label(act, label));
      LinearLayout r = Fx.hbox(act); r.setBackground(Ui.rr(act, 0xFF080616, 16, 0xFF5A4720, 1)); r.setPadding(Fx.dp(act, 14), Fx.dp(act, 4), Fx.dp(act, 14), Fx.dp(act, 4));
      r.addView(Fx.text(act, emoji, 18, Fx.TX)); e.setBackground(null); r.addView(e, new LinearLayout.LayoutParams(0, Fx.WRAP, 1f));
      if (eye) { final boolean[] show = {false}; TextView b = Fx.text(act, "👁", 18, Fx.MU);
        b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { show[0] = !show[0]; e.setInputType(InputType.TYPE_CLASS_TEXT | (show[0] ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD)); e.setSelection(e.getText().length()); } }); r.addView(b); }
      w.addView(r); return w;
    }
    private void render() {
      box.removeAllViews();
      if (!adminOnly) {
        LinearLayout tabs = Fx.hbox(act); tabs.setGravity(Gravity.CENTER); tabs.setBackground(Ui.rr(act, 0xFF050310, 24, 0xFF3A2D12, 1)); tabs.setPadding(Fx.dp(act, 4), Fx.dp(act, 4), Fx.dp(act, 4), Fx.dp(act, 4));
        tabs.addView(Fx.chip(act, "🔑 ورود", !reg, new View.OnClickListener() { public void onClick(View v) { reg = false; render(); } }), Fx.wt(act, 1, 0));
        tabs.addView(Fx.chip(act, "🚀 ثبت‌نام", reg, new View.OnClickListener() { public void onClick(View v) { reg = true; render(); } }), Fx.wt(act, 1, 0));
        box.addView(tabs);
      }
      TextView ic = Fx.text(act, adminOnly ? "🔐" : reg ? "🚀" : "🔑", 34, Fx.TX); ic.setGravity(Gravity.CENTER); box.addView(ic, Fx.lp(act, Fx.MATCH, Fx.WRAP, 14));
      TextView hd = Fx.gold(act, adminOnly ? "ورود به پنل" : reg ? "ساخت حساب جدید" : "ورود به حساب", 20); hd.setGravity(Gravity.CENTER); box.addView(hd, Fx.lp(act, Fx.MATCH, Fx.WRAP, 4));
      TextView sb = Fx.text(act, adminOnly ? "نام کاربری و رمز مدیر را وارد کنید." : reg ? "چند ثانیه وقت بگذارید و حساب بسازید." : "خوش آمدید! اطلاعات حساب خود را وارد کنید.", 14, Fx.MU); sb.setGravity(Gravity.CENTER); box.addView(sb, Fx.lp(act, Fx.MATCH, Fx.WRAP, 6));
      final EditText u = Fx.input(act, "نام کاربری", InputType.TYPE_CLASS_TEXT);
      final EditText ph = Fx.input(act, "09123456789", InputType.TYPE_CLASS_PHONE);
      final EditText cd = Fx.input(act, "۱۶ رقم، برای دریافت پول", InputType.TYPE_CLASS_NUMBER);
      final EditText pw = Fx.input(act, "رمز عبور", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
      u.setAutofillHints(View.AUTOFILL_HINT_USERNAME); pw.setAutofillHints(View.AUTOFILL_HINT_PASSWORD);
      if (!reg) { u.setText(Session.savedUser()); pw.setText(Session.savedPass()); }
      box.addView(fld("👤", "نام کاربری", u, false));
      if (reg) { box.addView(fld("📱", "شماره موبایل", ph, false)); box.addView(fld("💳", "شماره کارت پیش‌فرض", cd, false)); }
      box.addView(fld("🔒", "رمز عبور", pw, true));
      final TextView msg = Fx.text(act, "", 13, Fx.BAD); box.addView(msg, Fx.lp(act, Fx.WRAP, Fx.WRAP, 8));
      box.addView(Fx.button(act, reg ? "ساخت حساب" : "ورود", new View.OnClickListener() { public void onClick(View v) {
        JSONObject b = reg ? Api.obj("username", u.getText().toString().trim(), "phone", ph.getText().toString().trim(), "card", cd.getText().toString().trim(), "password", pw.getText().toString())
                           : Api.obj("username", u.getText().toString().trim(), "password", pw.getText().toString());
        msg.setText("لطفاً صبر کنید…"); msg.setTextColor(Fx.MU);
        Api.post(reg ? "/api/register" : "/api/login", b, new Api.Cb() { public void done(JSONObject r, String e) {
          if (e != null) { msg.setText(e); msg.setTextColor(Fx.BAD); return; }
          JSONObject user = r.optJSONObject("user");
          if (adminOnly && (user == null || !"admin".equals(user.optString("role")))) { msg.setText("این حساب مدیر نیست."); msg.setTextColor(Fx.BAD); return; }
          Session.set(r.optString("token")); Session.saveCred(u.getText().toString().trim(), pw.getText().toString()); act.replaceAll(next.make());
        } });
      } }), Fx.lp(act, Fx.MATCH, Fx.WRAP, 12));
    }
  }
}
