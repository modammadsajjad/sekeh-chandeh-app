package com.sekehchandeh.core;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
public class Auth {
  public interface Next { Screen make(); }
  public static class Splash extends Screen {
    private final Next next; private final boolean adminOnly; private TextView st; private TextView retry;
    public Splash(Next n, boolean adminOnly) { next = n; this.adminOnly = adminOnly; }
    @Override public View create() {
      LinearLayout c = Fx.vbox(act); c.setGravity(Gravity.CENTER); c.setPadding(Fx.dp(act, 30), 0, Fx.dp(act, 30), 0);
      c.addView(Fx.logo(act, 150));
      c.addView(Fx.gold(act, adminOnly ? "مدیریت سکه چنده" : "سکه چنده", 28), Fx.lp(act, Fx.WRAP, Fx.WRAP, 14));
      st = Fx.text(act, "در حال اتصال به سرور…\nبار اول ممکن است تا یک دقیقه طول بکشد.", 13, Fx.MU); st.setGravity(Gravity.CENTER);
      c.addView(st, Fx.lp(act, Fx.WRAP, Fx.WRAP, 16));
      retry = Fx.button(act, "تلاش دوباره", new View.OnClickListener() { public void onClick(View v) { go(); } });
      retry.setVisibility(View.GONE); c.addView(retry, Fx.lp(act, Fx.WRAP, Fx.WRAP, 16));
      return c;
    }
    @Override public void shown() { go(); }
    private void fail(String e) { st.setText(e); st.setTextColor(Fx.BAD); retry.setVisibility(View.VISIBLE); }
    private void go() {
      retry.setVisibility(View.GONE); st.setTextColor(Fx.MU);
      Api.get("/api/features", new Api.Cb() { public void done(JSONObject r, String e) {
        if (e != null) { fail(e); return; }
        Api.setFeatures(r.optJSONObject("features"));
        if (Session.token() == null) { act.replaceAll(new Login(next, adminOnly)); return; }
        Api.get("/api/me", new Api.Cb() { public void done(JSONObject r2, String e2) {
          if (e2 != null) { fail(e2); return; }
          JSONObject u = r2.optJSONObject("user");
          if (adminOnly && (u == null || !"admin".equals(u.optString("role")))) { Session.clear(); act.replaceAll(new Login(next, true)); return; }
          act.replaceAll(next.make());
        } });
      } });
    }
  }
  public static class Login extends Screen {
    private final Next next; private final boolean adminOnly; private boolean reg = false; private LinearLayout box;
    public Login(Next n, boolean adminOnly) { next = n; this.adminOnly = adminOnly; }
    @Override public View create() {
      ScrollView sv = new ScrollView(act); LinearLayout c = Fx.vbox(act); c.setGravity(Gravity.CENTER_HORIZONTAL);
      c.setPadding(Fx.dp(act, 20), Fx.dp(act, 40), Fx.dp(act, 20), Fx.dp(act, 20)); sv.addView(c);
      c.addView(Fx.logo(act, 130));
      c.addView(Fx.gold(act, adminOnly ? "ورود مدیر" : "سکه چنده", 26), Fx.lp(act, Fx.WRAP, Fx.WRAP, 10));
      box = Fx.card(act); c.addView(box, Fx.lp(act, Fx.MATCH, Fx.WRAP, 24));
      render();
      return sv;
    }
    private void render() {
      box.removeAllViews();
      if (!adminOnly) {
        LinearLayout tabs = Fx.hbox(act); tabs.setGravity(Gravity.CENTER);
        tabs.addView(Fx.chip(act, "ورود", !reg, new View.OnClickListener() { public void onClick(View v) { reg = false; render(); } }), Fx.wt(act, 1, 0));
        tabs.addView(Fx.chip(act, "ثبت‌نام", reg, new View.OnClickListener() { public void onClick(View v) { reg = true; render(); } }), Fx.wt(act, 1, 0));
        box.addView(tabs);
      }
      final EditText u = Fx.input(act, "نام کاربری", InputType.TYPE_CLASS_TEXT);
      final EditText ph = Fx.input(act, "شماره موبایل (۰۹...)", InputType.TYPE_CLASS_PHONE);
      final EditText cd = Fx.input(act, "شماره کارت ۱۶ رقمی", InputType.TYPE_CLASS_NUMBER);
      final EditText pw = Fx.input(act, "رمز عبور", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
      u.setAutofillHints(View.AUTOFILL_HINT_USERNAME); pw.setAutofillHints(View.AUTOFILL_HINT_PASSWORD);
      if (!reg) { u.setText(Session.savedUser()); pw.setText(Session.savedPass()); }
      box.addView(u, Fx.lp(act, Fx.MATCH, Fx.WRAP, 14));
      if (reg) { box.addView(ph, Fx.lp(act, Fx.MATCH, Fx.WRAP, 10)); box.addView(cd, Fx.lp(act, Fx.MATCH, Fx.WRAP, 10)); }
      box.addView(pw, Fx.lp(act, Fx.MATCH, Fx.WRAP, 10));
      final TextView msg = Fx.text(act, "", 13, Fx.BAD); box.addView(msg, Fx.lp(act, Fx.WRAP, Fx.WRAP, 8));
      box.addView(Fx.button(act, reg ? "ساخت حساب" : "ورود", new View.OnClickListener() { public void onClick(View v) {
        JSONObject b = reg ? Api.obj("username", u.getText().toString().trim(), "phone", ph.getText().toString().trim(), "card", cd.getText().toString().trim(), "password", pw.getText().toString())
                           : Api.obj("username", u.getText().toString().trim(), "password", pw.getText().toString());
        msg.setText("لطفاً صبر کنید…"); msg.setTextColor(Fx.MU);
        Api.post(reg ? "/api/register" : "/api/login", b, new Api.Cb() { public void done(JSONObject r, String e) {
          if (e != null) { msg.setText(e); msg.setTextColor(Fx.BAD); return; }
          JSONObject user = r.optJSONObject("user");
          if (adminOnly && (user == null || !"admin".equals(user.optString("role")))) { msg.setText("این حساب مدیر نیست."); msg.setTextColor(Fx.BAD); return; }
          Session.set(r.optString("token")); Session.saveCred(u.getText().toString().trim(), pw.getText().toString()); act.replaceAll(next.make());
        } });
      } }), Fx.lp(act, Fx.MATCH, Fx.WRAP, 12));
    }
  }
}
