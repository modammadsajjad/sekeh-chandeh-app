package com.sekehchandeh.core;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
public class TabsScreen extends Screen {
  public interface Maker { View make(BaseActivity a); }
  public static class Tab { final String label, icon; final Maker maker; public Tab(String l, String i, Maker m) { label = l; icon = i; maker = m; } }
  private final String title; private final Tab[] tabs; private int cur = 0; public static TabsScreen last;
  public void goTo(int i) { if (i >= 0 && i < tabs.length) select(i); }
  private FrameLayout content; private final ImageView[] icons; private final TextView[] labels;
  public TabsScreen(String title, Tab[] tabs, int start) { this(title, tabs); cur = start; }
  public TabsScreen(String title, Tab[] tabs) { this.title = title; this.tabs = tabs; icons = new ImageView[tabs.length]; labels = new TextView[tabs.length]; }
  @Override public View create() {
    last = this;
    LinearLayout col = Fx.vbox(act);
    LinearLayout head = Fx.hbox(act); head.setPadding(Fx.dp(act, 16), Fx.dp(act, 10), Fx.dp(act, 16), Fx.dp(act, 10));
    head.addView(Fx.logo(act, 40));
    TextView t = Fx.gold(act, title, 20); t.setPadding(Fx.dp(act, 10), 0, 0, 0); head.addView(t);
    col.addView(head);
    View line = new View(act); line.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0x00E7B94F, Fx.GOLD, 0x00E7B94F}));
    col.addView(line, new LinearLayout.LayoutParams(Fx.MATCH, Fx.dp(act, 1)));
    content = new FrameLayout(act); col.addView(content, new LinearLayout.LayoutParams(Fx.MATCH, 0, 1f));
    LinearLayout nav = Fx.hbox(act); nav.setBackground(Fx.cardBg(act, 0)); nav.setPadding(0, Fx.dp(act, 6), 0, Fx.dp(act, 8));
    for (int i = 0; i < tabs.length; i++) {
      final int idx = i;
      LinearLayout item = Fx.vbox(act); item.setGravity(Gravity.CENTER);
      icons[i] = new ImageView(act); labels[i] = Fx.text(act, tabs[i].label, 11, Fx.MU);
      item.addView(icons[i], new LinearLayout.LayoutParams(Fx.dp(act, 28), Fx.dp(act, 28))); item.addView(labels[i]);
      item.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { select(idx); } });
      nav.addView(item, new LinearLayout.LayoutParams(0, Fx.WRAP, 1f));
    }
    col.addView(nav, new LinearLayout.LayoutParams(Fx.MATCH, Fx.WRAP));
    select(cur);
    return col;
  }
  private void select(int i) {
    cur = i; content.removeAllViews(); View v = tabs[i].maker.make(act); content.addView(v, new FrameLayout.LayoutParams(Fx.MATCH, Fx.MATCH));
    v.setAlpha(0f); v.animate().alpha(1f).setDuration(180).start();
    for (int k = 0; k < tabs.length; k++) { boolean on = k == i; icons[k].setImageDrawable(on ? Icons.gold(act, tabs[k].icon, 28) : Icons.dim(act, tabs[k].icon, 28)); labels[k].setTextColor(on ? Fx.GOLD2 : Fx.MU); }
  }
}
