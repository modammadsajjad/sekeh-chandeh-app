package com.sekehchandeh.core;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
public class TabsScreen extends Screen {
  public interface Maker { View make(BaseActivity a); }
  public static class Tab { final String label, icon; final Maker maker; public Tab(String l, String i, Maker m) { label = l; icon = i; maker = m; } }
  private final String title; private final Tab[] tabs; private int cur = 0;
  public static TabsScreen last;
  public Runnable bell, orders, ai;
  private FrameLayout content; private LinearLayout navRow;
  public TabsScreen(String title, Tab[] tabs, int start) { this(title, tabs); cur = start; }
  public TabsScreen(String title, Tab[] tabs) { this.title = title; this.tabs = tabs; }
  public void goTo(int i) { if (i >= 0 && i < tabs.length) select(i); }
  private TextView tbtn(String t, View.OnClickListener l) { return Ui.pill(act, t, l); }
  private View topBar() {
    LinearLayout h = Fx.hbox(act); int p = Fx.dp(act, 12);
    h.setPadding(p, Fx.dp(act, 10), p, Fx.dp(act, 12));
    float r = Fx.dp(act, 22);
    GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xF20B0906, 0xF2241A0A, 0xF20B0906});
    g.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r}); g.setStroke(Fx.dp(act, 1), 0x66B78B38);
    h.setBackground(g);
    if (orders != null) {
      h.addView(tbtn("☰", v -> goTo(tabs.length - 1)));
      ImageView lg = Fx.logo(act, 46); ((LinearLayout.LayoutParams) lg.getLayoutParams()).setMarginStart(Fx.dp(act, 10)); h.addView(lg);
      TextView b = Fx.text(act, "SEKEHCHANDEH", 13, 0xFFF0DFB5); b.setLetterSpacing(0.2f); b.setGravity(Gravity.CENTER); b.setSingleLine(true);
      h.addView(b, new LinearLayout.LayoutParams(0, Fx.WRAP, 1f));
      h.addView(tbtn("🔔", v -> { if (bell != null) bell.run(); }));
      TextView o = tbtn("سفارشات", v -> orders.run());
      LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(Fx.WRAP, Fx.WRAP); op.setMarginStart(Fx.dp(act, 8)); h.addView(o, op);
    } else {
      h.addView(Fx.logo(act, 40));
      TextView t = Fx.gold(act, title, 20); t.setPadding(Fx.dp(act, 10), 0, 0, 0); h.addView(t);
    }
    return h;
  }
  @Override public View create() {
    last = this;
    FrameLayout root = new FrameLayout(act); root.setClipChildren(false);
    LinearLayout col = Fx.vbox(act); col.setClipChildren(false);
    col.addView(topBar());
    content = new FrameLayout(act); col.addView(content, new LinearLayout.LayoutParams(Fx.MATCH, 0, 1f));
    FrameLayout wrap = new FrameLayout(act); wrap.setClipChildren(false); wrap.setClipToPadding(false);
    int m = Fx.dp(act, 12); wrap.setPadding(m, Fx.dp(act, 22), m, Fx.dp(act, 10));
    navRow = Fx.hbox(act); navRow.setClipChildren(false);
    GradientDrawable ng = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xF235280F, 0xF2100C07});
    ng.setCornerRadius(Fx.dp(act, 28)); ng.setStroke(Fx.dp(act, 1), 0x99B58A3E);
    navRow.setBackground(ng);
    wrap.addView(navRow, new FrameLayout.LayoutParams(Fx.MATCH, Fx.dp(act, 72)));
    col.addView(wrap, new LinearLayout.LayoutParams(Fx.MATCH, Fx.WRAP));
    root.addView(col, new FrameLayout.LayoutParams(Fx.MATCH, Fx.MATCH));
    if (ai != null) {
      TextView fab = Fx.text(act, "✦", 26, 0xFF1B1405); fab.setGravity(Gravity.CENTER);
      GradientDrawable fg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFFEFD389, 0xFF976F22}); fg.setShape(GradientDrawable.OVAL); fg.setStroke(Fx.dp(act, 1), 0xBBFFEEB8);
      fab.setBackground(fg); fab.setOnClickListener(v -> ai.run());
      FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(Fx.dp(act, 54), Fx.dp(act, 54), Gravity.BOTTOM | Gravity.LEFT);
      fp.leftMargin = Fx.dp(act, 16); fp.bottomMargin = Fx.dp(act, 118); root.addView(fab, fp);
    }
    select(cur);
    return root;
  }
  private void renderNav() {
    navRow.removeAllViews();
    for (int i = 0; i < tabs.length; i++) {
      final int idx = i; boolean on = i == cur;
      FrameLayout item = new FrameLayout(act); item.setClipChildren(false);
      if (on) {
        ImageView ic = new ImageView(act); ic.setImageDrawable(Icons.icon(act, tabs[i].icon, 30, 0xFF3A2808, 0xFF1B1405));
        FrameLayout orb = new FrameLayout(act);
        GradientDrawable og = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFFFFF0AD, 0xFFD6A33E}); og.setShape(GradientDrawable.OVAL); og.setStroke(Fx.dp(act, 3), 0xAAFFE6A0);
        orb.setBackground(og); orb.setElevation(Fx.dp(act, 8)); orb.addView(ic, new FrameLayout.LayoutParams(Fx.dp(act, 30), Fx.dp(act, 30), Gravity.CENTER));
        FrameLayout.LayoutParams op = new FrameLayout.LayoutParams(Fx.dp(act, 60), Fx.dp(act, 60), Gravity.TOP | Gravity.CENTER_HORIZONTAL); op.topMargin = -Fx.dp(act, 26); item.addView(orb, op);
        TextView lb = Fx.text(act, tabs[i].label, 13, Fx.GOLD2); lb.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Fx.WRAP, Fx.WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL); lp.bottomMargin = Fx.dp(act, 8); item.addView(lb, lp);
      } else {
        LinearLayout v = Fx.vbox(act); v.setGravity(Gravity.CENTER);
        ImageView ic = new ImageView(act); ic.setImageDrawable(Icons.icon(act, tabs[i].icon, 26, 0xFFE7D6A8, 0xFFA8956A));
        v.addView(ic, new LinearLayout.LayoutParams(Fx.dp(act, 26), Fx.dp(act, 26)));
        TextView lb = Fx.text(act, tabs[i].label, 11, 0xFFD9C9A0); lb.setGravity(Gravity.CENTER); v.addView(lb, Fx.lp(act, Fx.WRAP, Fx.WRAP, 3));
        item.addView(v, new FrameLayout.LayoutParams(Fx.MATCH, Fx.MATCH));
      }
      item.setOnClickListener(x -> select(idx));
      navRow.addView(item, new LinearLayout.LayoutParams(0, Fx.MATCH, 1f));
    }
  }
  private void select(int i) {
    cur = i; content.removeAllViews(); View v = tabs[i].maker.make(act); content.addView(v, new FrameLayout.LayoutParams(Fx.MATCH, Fx.MATCH));
    v.setAlpha(0f); v.animate().alpha(1f).setDuration(180).start();
    renderNav();
  }
}
