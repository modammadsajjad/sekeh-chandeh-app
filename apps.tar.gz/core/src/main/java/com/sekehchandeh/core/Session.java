package com.sekehchandeh.core;
import android.content.Context;
import android.content.SharedPreferences;
public class Session {
  private static SharedPreferences sp;
  public static void init(Context c) { if (sp == null) sp = c.getApplicationContext().getSharedPreferences("sc", Context.MODE_PRIVATE); }
  public static String token() { return sp == null ? null : sp.getString("token", null); }
  public static void set(String t) { sp.edit().putString("token", t).apply(); }
  public static String savedUser() { return sp == null ? "" : sp.getString("su", ""); }
  public static String savedPass() { return sp == null ? "" : sp.getString("sp", ""); }
  public static void saveCred(String u, String p) { sp.edit().putString("su", u).putString("sp", p).apply(); }
  public static void clear() { sp.edit().remove("token").apply(); }
}
