package com.sekehchandeh.core;
import android.content.Context;
import android.content.SharedPreferences;
public class Session {
  private static SharedPreferences sp;
  public static void init(Context c) { if (sp == null) sp = c.getApplicationContext().getSharedPreferences("sc", Context.MODE_PRIVATE); }
  public static String token() { return sp == null ? null : sp.getString("token", null); }
  public static void set(String t) { sp.edit().putString("token", t).apply(); }
  public static void clear() { sp.edit().remove("token").apply(); }
}
