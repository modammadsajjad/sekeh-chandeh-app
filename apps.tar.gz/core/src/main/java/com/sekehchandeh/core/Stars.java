package com.sekehchandeh.core;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;
import java.util.Random;
public class Stars extends View {
  private final float[] x = new float[80], y = new float[80], r = new float[80], ph = new float[80];
  private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), bg = new Paint();
  private final long t0 = System.nanoTime();
  public Stars(Context c) {
    super(c);
    Random rnd = new Random(7);
    for (int i = 0; i < x.length; i++) { x[i] = rnd.nextFloat(); y[i] = rnd.nextFloat(); r[i] = Fx.dp(c, 0.5f + rnd.nextFloat() * 1.3f); ph[i] = rnd.nextFloat() * 6.28f; }
  }
  @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
    bg.setShader(new RadialGradient(w / 2f, 0, Math.max(w, h) * 0.9f, new int[]{0xFF3A2A0A, 0xFF120D05, Fx.BG}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
  }
  @Override protected void onDraw(Canvas cv) {
    int w = getWidth(), h = getHeight();
    cv.drawRect(0, 0, w, h, bg);
    float t = (System.nanoTime() - t0) / 1e9f;
    for (int i = 0; i < x.length; i++) {
      float a = 0.3f + 0.7f * (0.5f + 0.5f * (float) Math.sin(t * (0.8f + (i % 5) * 0.3f) + ph[i]));
      p.setColor(((int) (255 * a) << 24) | 0xF7DF91);
      cv.drawCircle(x[i] * w, y[i] * h, r[i], p);
    }
    postInvalidateDelayed(40);
  }
}
