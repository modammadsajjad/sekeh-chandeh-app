package com.sekehchandeh.core;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
public class Icons {
  public static Drawable icon(Context c, String kind, int sizeDp, int c1, int c2) { return new D(kind, Fx.dp(c, sizeDp), c1, c2); }
  public static Drawable gold(Context c, String kind, int sizeDp) { return icon(c, kind, sizeDp, Fx.GOLD2, Fx.GOLD3); }
  public static Drawable dim(Context c, String kind, int sizeDp) { return icon(c, kind, sizeDp, 0xFF8F8466, 0xFF4E4631); }
  static class D extends Drawable {
    final String k; final int sz, c1, c2;
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); final Path path = new Path();
    D(String k, int sz, int c1, int c2) { this.k = k; this.sz = sz; this.c1 = c1; this.c2 = c2; }
    @Override public int getIntrinsicWidth() { return sz; }
    @Override public int getIntrinsicHeight() { return sz; }
    @Override public void draw(Canvas cv) {
      Rect b = getBounds(); int s = Math.min(b.width(), b.height());
      if (s <= 0) return;
      cv.save(); cv.translate(b.left, b.top); cv.scale(s / 100f, s / 100f);
      p.setShader(new LinearGradient(0, 0, 0, 100, c1, c2, Shader.TileMode.CLAMP));
      p.setStyle(Paint.Style.FILL); p.setShadowLayer(3, 0, 2, 0xAA000000);
      glyph(cv);
      p.setShader(null); p.clearShadowLayer(); cv.restore();
    }
    void cut() { p.setShader(null); p.clearShadowLayer(); p.setColor(Fx.BG); }
    void poly(Canvas cv, float... v) { path.reset(); path.moveTo(v[0], v[1]); for (int i = 2; i + 1 < v.length; i += 2) path.lineTo(v[i], v[i + 1]); path.close(); cv.drawPath(path, p); }
    void glyph(Canvas cv) {
      switch (k) {
        case "home": poly(cv, 50, 10, 6, 50, 18, 50, 18, 88, 82, 88, 82, 50, 94, 50); cut(); cv.drawRect(42, 60, 58, 88, p); break;
        case "coin": cv.drawCircle(50, 50, 42, p); p.setShader(null); p.setColor(0x66000000); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); cv.drawCircle(50, 50, 28, p); break;
        case "trophy": poly(cv, 28, 12, 72, 12, 68, 44, 50, 58, 32, 44); cv.drawRect(45, 58, 55, 74, p); cv.drawRect(30, 74, 70, 86, p);
          p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(6); cv.drawArc(new RectF(8, 14, 38, 42), 90, 180, false, p); cv.drawArc(new RectF(62, 14, 92, 42), -90, 180, false, p); break;
        case "user": cv.drawCircle(50, 32, 18, p); cv.drawArc(new RectF(18, 56, 82, 120), 180, 180, true, p); break;
        case "chat": cv.drawRoundRect(new RectF(8, 14, 92, 68), 14, 14, p); poly(cv, 28, 62, 28, 90, 52, 64); break;
        case "wallet": cv.drawRoundRect(new RectF(8, 24, 92, 84), 12, 12, p); cut(); cv.drawCircle(72, 54, 7, p); break;
        case "bell": cv.drawArc(new RectF(24, 12, 76, 64), 180, 180, true, p); poly(cv, 24, 38, 76, 38, 88, 74, 12, 74); cv.drawCircle(50, 84, 8, p); break;
        case "gear": for (int i = 0; i < 8; i++) { cv.save(); cv.rotate(i * 45, 50, 50); cv.drawRect(43, 6, 57, 28, p); cv.restore(); }
          cv.drawCircle(50, 50, 32, p); cut(); cv.drawCircle(50, 50, 13, p); break;
        case "cart": cv.drawRect(6, 14, 24, 22, p); poly(cv, 22, 28, 92, 28, 82, 62, 32, 62); cv.drawCircle(40, 80, 8, p); cv.drawCircle(74, 80, 8, p); break;
        case "bag": cv.drawRoundRect(new RectF(16, 36, 84, 90), 8, 8, p); cv.drawRect(32, 14, 40, 42, p); cv.drawRect(60, 14, 68, 42, p); cv.drawRect(32, 14, 68, 22, p); break;
        case "list": for (int i = 0; i < 3; i++) cv.drawRoundRect(new RectF(14, 18 + i * 26, 86, 32 + i * 26), 7, 7, p); break;
        case "chart": cv.drawRoundRect(new RectF(12, 52, 32, 88), 5, 5, p); cv.drawRoundRect(new RectF(40, 28, 60, 88), 5, 5, p); cv.drawRoundRect(new RectF(68, 10, 88, 88), 5, 5, p); break;
        case "crown": poly(cv, 8, 78, 8, 30, 30, 52, 50, 16, 70, 52, 92, 30, 92, 78); cv.drawRect(8, 82, 92, 92, p); break;
        default: path.reset(); for (int i = 0; i < 10; i++) { double a = -Math.PI / 2 + i * Math.PI / 5; float rr = (i % 2 == 0) ? 44 : 18; float px = 50 + (float) Math.cos(a) * rr, py = 52 + (float) Math.sin(a) * rr; if (i == 0) path.moveTo(px, py); else path.lineTo(px, py); } path.close(); cv.drawPath(path, p);
      }
    }
    @Override public void setAlpha(int a) { }
    @Override public void setColorFilter(ColorFilter f) { }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
  }
}
