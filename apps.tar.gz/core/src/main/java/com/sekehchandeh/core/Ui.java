package com.sekehchandeh.core;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
public class Ui {
  public static final int NAVY = 0xFF0C0A1E;
  public interface Pick { void on(int i); }
  public static GradientDrawable rr(Context c, int color, float r, int stroke, float sw) {
    GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(Fx.dp(c, r)); if (sw > 0) g.setStroke(Fx.dp(c, sw), stroke); return g;
  }
  public static GradientDrawable goldBg(Context c, float r) {
    GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFFFFF0AD, 0xFFE9BD58, 0xFFA8751E});
    g.setCornerRadius(Fx.dp(c, r)); g.setStroke(Fx.dp(c, 1), 0xFFF9DF91); return g;
  }
  public static TextView pill(Context c, String t, View.OnClickListener l) {
    TextView b = Fx.text(c, t, 14, 0xFFF5D77B); b.setGravity(Gravity.CENTER); b.setTypeface(Typeface.DEFAULT_BOLD);
    b.setBackground(rr(c, 0xFF171108, 14, 0xFF8C682C, 1)); b.setPadding(Fx.dp(c, 12), Fx.dp(c, 9), Fx.dp(c, 12), Fx.dp(c, 9)); b.setOnClickListener(l); return b;
  }
  public static ImageView titleImg(Context c, String name, int hDp) {
    ImageView v = new ImageView(c); int id = 0;
    switch (name) { case "t_brand": id = R.drawable.t_brand; break; case "t_hero": id = R.drawable.t_hero; break; case "t_prices": id = R.drawable.t_prices; break; case "t_start": id = R.drawable.t_start; break; case "t_faq": id = R.drawable.t_faq; break; case "t_account": id = R.drawable.t_account; break; default: id = R.drawable.t_more; }
    v.setImageResource(id); v.setAdjustViewBounds(true); v.setScaleType(ImageView.ScaleType.FIT_START);
    v.setLayoutParams(new LinearLayout.LayoutParams(Fx.WRAP, Fx.dp(c, hDp))); return v;
  }
  static String imgFor(String t) {
    if (t.contains("قیمت‌ها")) return "t_prices"; if (t.contains("چطور شروع")) return "t_start"; if (t.contains("سؤالات متداول")) return "t_faq";
    if (t.contains("حساب کاربری")) return "t_account"; if (t.contains("بیشتر")) return "t_more"; return null;
  }
  public static LinearLayout title(Context c, String t) {
    LinearLayout l = Fx.vbox(c); l.setPadding(0, Fx.dp(c, 18), 0, Fx.dp(c, 10));
    String img = imgFor(t);
    if (img != null) { LinearLayout r = Fx.hbox(c); int sp = t.indexOf(' ');
      if (sp > 0) { TextView em = Fx.text(c, t.substring(0, sp), 22, Fx.TX); em.setPadding(0, 0, Fx.dp(c, 8), 0); r.addView(em); }
      r.addView(titleImg(c, img, 38)); l.addView(r); }
    else l.addView(Fx.gold(c, t, 19));
    View bar = new View(c); bar.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0x00E7B94F, 0xFFF1D98C}));
    l.addView(bar, new LinearLayout.LayoutParams(Fx.dp(c, 110), Fx.dp(c, 3)));
    ((LinearLayout.LayoutParams) bar.getLayoutParams()).topMargin = Fx.dp(c, 6);
    return l;
  }
  public static LinearLayout navy(Context c) {
    LinearLayout l = Fx.vbox(c); l.setBackground(rr(c, NAVY, 22, 0x88725522, 1.2f)); int p = Fx.dp(c, 16); l.setPadding(p, p, p, p); return l;
  }
  public static TextView label(Context c, String t) { TextView x = Fx.text(c, t, 13, Fx.MU); x.setPadding(0, Fx.dp(c, 10), 0, Fx.dp(c, 6)); return x; }
  public static TextView select(final Context c, final String hint, final String[] items, final Pick p) {
    final TextView t = Fx.text(c, hint, 15, Fx.MU); t.setGravity(Gravity.CENTER_VERTICAL);
    t.setBackground(rr(c, NAVY, 14, 0xFF5A4720, 1)); int d = Fx.dp(c, 14); t.setPadding(d, d, d, d);
    t.setOnClickListener(v -> new AlertDialog.Builder(c).setItems(items, (dg, i) -> { t.setText(items[i]); t.setTextColor(Fx.TX); p.on(i); }).show());
    return t;
  }
  public static LinearLayout two(Context c, View a, View b) {
    LinearLayout r = Fx.hbox(c); r.setBaselineAligned(false);
    LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, Fx.WRAP, 1f); p1.setMarginEnd(Fx.dp(c, 6));
    LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, Fx.WRAP, 1f); p2.setMarginStart(Fx.dp(c, 6));
    r.addView(a, p1); r.addView(b, p2); return r;
  }
  public static void openUrl(Context c, String url) { try { c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { } }
  public static ImageView img(Context c, String name, int wDp, int hDp, boolean round) {
    ImageView v = new ImageView(c); int id = 0;
    switch (name) { case "coin3d": id = R.drawable.coin3d; break; case "chan": id = R.drawable.chan; break; case "robot": id = R.drawable.robot; break; case "ornament": id = R.drawable.ornament; break; default: id = R.drawable.logo; }
    v.setImageResource(id); v.setScaleType(ImageView.ScaleType.FIT_CENTER);
    if (round) { final boolean circle = wDp == hDp; final float r = Fx.dp(c, wDp) * 0.5f; final float r2 = Fx.dp(c, 22);
      v.setOutlineProvider(new android.view.ViewOutlineProvider() { public void getOutline(View x, android.graphics.Outline o) { o.setRoundRect(0, 0, x.getWidth(), x.getHeight(), circle ? r : r2); } }); v.setClipToOutline(true); }
    v.setLayoutParams(new LinearLayout.LayoutParams(wDp < 0 ? Fx.MATCH : Fx.dp(c, wDp), Fx.dp(c, hDp))); return v;
  }
  public static View hex(Context c, String emoji, int sizeDp) {
    android.widget.FrameLayout f = new android.widget.FrameLayout(c);
    final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG); fill.setColor(NAVY); final Paint st = new Paint(Paint.ANTI_ALIAS_FLAG); st.setStyle(Paint.Style.STROKE); st.setColor(0xFF1E88E5); st.setStrokeWidth(Fx.dp(c, 3));
    View h = new View(c) { @Override protected void onDraw(Canvas cv) {
      float cx = getWidth() / 2f, cy = getHeight() / 2f, r = Math.min(cx, cy) - 4; Path p = new Path();
      for (int i = 0; i < 6; i++) { double a = Math.toRadians(60 * i - 90); float x = cx + (float) (r * Math.cos(a)), y = cy + (float) (r * Math.sin(a)); if (i == 0) p.moveTo(x, y); else p.lineTo(x, y); }
      p.close(); cv.drawPath(p, fill); cv.drawPath(p, st); } };
    f.addView(h, new android.widget.FrameLayout.LayoutParams(Fx.dp(c, sizeDp), Fx.dp(c, sizeDp)));
    TextView t = Fx.text(c, emoji, sizeDp / 3.2f, 0xFFFFFFFF); t.setGravity(Gravity.CENTER);
    f.addView(t, new android.widget.FrameLayout.LayoutParams(Fx.dp(c, sizeDp), Fx.dp(c, sizeDp)));
    f.setLayoutParams(new LinearLayout.LayoutParams(Fx.dp(c, sizeDp), Fx.dp(c, sizeDp))); return f;
  }
}
