package com.sekehchandeh.core;
import android.view.View;
public abstract class Screen {
  public BaseActivity act;
  public abstract View create();
  public void shown() { }
}
