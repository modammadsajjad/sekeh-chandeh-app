package com.sekehchandeh.admin;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Typeface;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.sekehchandeh.core.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
public class AdminActivity extends BaseActivity {
  static final Auth.Next NEXT = new Auth.Next() { public Screen make() {
    return new TabsScreen("مدیریت سکه چنده", new TabsScreen.Tab[]{
      new TabsScreen.Tab("داشبورد", "home", AdminActivity::dash), new TabsScreen.Tab("سفارشات", "bag", AdminActivity::orders),
      new TabsScreen.Tab("سکه‌ها", "coin", AdminActivity::coins), new TabsScreen.Tab("کاربران", "user", AdminActivity::users), new TabsScreen.Tab("بیشتر", "list", AdminActivity::more) });
  } };
  @Override protected void start() {
    Api.onAuthFail = new Runnable() { public void run() { Session.clear(); Fx.toast(AdminActivity.this, "لطفاً دوباره وارد شوید."); replaceAll(new Auth.Login(NEXT, true)); } };
    replaceAll(new Auth.Splash(NEXT, true));
  }
  // ---------- ابزار ----------
  static ScrollView scroller(Context a, LinearLayout box) { int p = Fx.dp(a, 14); box.setPadding(p, p, p, Fx.dp(a, 24)); ScrollView sc = new ScrollView(a); sc.setClipChildren(false); sc.addView(box); return sc; }
  static LinearLayout.LayoutParams top(Context a, float t) { return Fx.lp(a, Fx.MATCH, Fx.WRAP, t); }
  static JSONArray list(JSONObject r) { if (r == null) return new JSONArray(); Iterator<String> it = r.keys(); while (it.hasNext()) { Object o = r.opt(it.next()); if (o instanceof JSONArray) return (JSONArray) o; } return new JSONArray(); }
  static String dt(long ms) { if (ms < 100000000000L) ms *= 1000; return new SimpleDateFormat("yyyy/MM/dd HH:mm").format(new Date(ms)); }
  static String faDigits(String s) { StringBuilder b = new StringBuilder(); for (char ch : s.toCharArray()) { if (ch >= '۰' && ch <= '۹') b.append((char) ('0' + (ch - '۰'))); else if (ch >= '٠' && ch <= '٩') b.append((char) ('0' + (ch - '٠'))); else b.append(ch); } return b.toString(); }
  static EditText field(Context a, String hint, String val, int type) { EditText e = Fx.input(a, hint, type); e.setText(val); e.setBackground(Ui.rr(a, Ui.NAVY, 14, 0xFF5A4720, 1)); return e; }
  static TextView smallBtn(Context a, String t, int color, View.OnClickListener l) {
    TextView b = Fx.text(a, t, 14, 0xFF1B1405); b.setTypeface(Typeface.DEFAULT_BOLD); b.setGravity(Gravity.CENTER); b.setBackground(Ui.rr(a, color, 14, 0, 0)); b.setPadding(Fx.dp(a, 14), Fx.dp(a, 10), Fx.dp(a, 14), Fx.dp(a, 10)); b.setOnClickListener(l); return b;
  }
  static View stat(Context a, String label, String value) {
    LinearLayout c = Fx.card(a); c.setGravity(Gravity.CENTER); c.addView(Fx.gold(a, value, 22)); TextView l = Fx.text(a, label, 12, Fx.MU); l.setGravity(Gravity.CENTER); c.addView(l, Fx.lp(a, Fx.WRAP, Fx.WRAP, 4)); return c;
  }
  static String statusLabel(String s) { switch (s) { case "review": return "⏳ در حال بررسی"; case "confirmed": return "✅ تایید شد"; case "rejected": return "❌ رد شد"; case "cancelled": return "🚫 لغو شد"; case "pending": return "⏳ در انتظار"; default: return s; } }
  static void showShot(final BaseActivity a, String path) {
    Fx.toast(a, "در حال دریافت عکس…");
    Api.image(path, bm -> { if (bm == null) { Fx.toast(a, "عکس یافت نشد."); return; }
      ImageView iv = new ImageView(a); iv.setImageBitmap(bm); iv.setAdjustViewBounds(true); new AlertDialog.Builder(a).setView(iv).setPositiveButton("بستن", null).show(); });
  }
  static void act(final BaseActivity a, final String path, final boolean askNote, final Runnable done) {
    if (!askNote) { Api.post(path, new JSONObject(), (r, e) -> { if (e != null) Fx.toast(a, e); done.run(); }); return; }
    final EditText n = Fx.input(a, "دلیل (اختیاری)", InputType.TYPE_CLASS_TEXT);
    new AlertDialog.Builder(a).setTitle("رد درخواست").setView(n).setPositiveButton("رد کن", (d, w) -> Api.post(path, Api.obj("note", n.getText().toString()), (r, e) -> { if (e != null) Fx.toast(a, e); done.run(); })).setNegativeButton("انصراف", null).show();
  }
  static Screen page(final String title, final TabsScreen.Maker body) {
    return new Screen() { public View create() { final BaseActivity a = act; LinearLayout c = Fx.vbox(a); c.setBackgroundColor(0xF0080706);
      LinearLayout h = Fx.hbox(a); h.setPadding(Fx.dp(a, 16), Fx.dp(a, 14), Fx.dp(a, 16), Fx.dp(a, 6)); h.addView(Fx.gold(a, title, 20), new LinearLayout.LayoutParams(0, Fx.WRAP, 1f)); h.addView(Ui.pill(a, "✕", v -> a.pop()));
      c.addView(h); c.addView(body.make(a), new LinearLayout.LayoutParams(Fx.MATCH, 0, 1f)); return c; } };
  }
  // ---------- داشبورد ----------
  static View dash(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); box.addView(Ui.title(a, "📊 داشبورد"));
    final LinearLayout body = Fx.vbox(a); box.addView(body); body.addView(Fx.text(a, "در حال بارگذاری…", 14, Fx.MU));
    Api.get("/api/admin/dashboard", (d, e) -> {
      body.removeAllViews(); if (d == null) { body.addView(Fx.text(a, e, 14, Fx.BAD)); return; }
      JSONObject rt = d.optJSONObject("rating"), td = d.optJSONObject("today");
      double avg = rt == null ? 0 : rt.optDouble("avg", 0);
      body.addView(Ui.two(a, stat(a, "سفارشات در انتظار", Fx.num(d.optLong("pending_orders"))), stat(a, "کیف پول در انتظار", Fx.num(d.optLong("pending_wallet")))));
      body.addView(Ui.two(a, stat(a, "کاربران", Fx.num(d.optLong("users"))), stat(a, "موجودی کل سکه‌ها", Fx.num(d.optLong("stock_total")))), top(a, 12));
      body.addView(Ui.two(a, stat(a, "امروز (تومان)", Fx.num(td == null ? 0 : td.optLong("amount"))), stat(a, "سفارش امروز", Fx.num(td == null ? 0 : td.optLong("orders")))), top(a, 12));
      body.addView(Ui.two(a, stat(a, "مجموع کیف پول‌ها (بدهی)", Fx.num(d.optLong("wallet_total"))), stat(a, "رضایت کاربران", avg > 0 ? String.format("%.1f", avg) + " ★" : "—")), top(a, 12)); });
    Api.get("/api/admin/report?days=30", (r, e) -> { if (r == null) return; JSONArray dl = r.optJSONArray("daily"); if (dl == null || dl.length() == 0) return;
      body.addView(Ui.title(a, "📋 جزئیات روزانه")); LinearLayout c = Fx.card(a); body.addView(c);
      for (int i = 0; i < dl.length() && i < 10; i++) { JSONObject x = dl.optJSONObject(i); LinearLayout row = Fx.vbox(a); row.setPadding(0, Fx.dp(a, 8), 0, Fx.dp(a, 8));
        row.addView(Fx.text(a, x.optString("d") + "  —  " + Fx.num(x.optLong("orders")) + " سفارش", 14, Fx.GOLD2));
        row.addView(Fx.text(a, "خرید " + Fx.num(x.optLong("buy")) + "  |  فروش " + Fx.num(x.optLong("sell")) + "  |  سود " + Fx.num(x.optLong("profit")), 13, Fx.MU)); c.addView(row); } });
    return scroller(a, box);
  }
  // ---------- سفارشات و کیف پول ----------
  static String ordSt = "review"; static boolean showWallet = false;
  static View orders(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); final LinearLayout bar = Fx.hbox(a); final LinearLayout body = Fx.vbox(a);
    final HorizontalScrollView hs = new HorizontalScrollView(a); hs.addView(bar); box.addView(hs); box.addView(body, top(a, 12));
    final Runnable[] reload = new Runnable[1];
    reload[0] = () -> {
      bar.removeAllViews(); body.removeAllViews();
      String[][] f = {{"review", "در حال بررسی"}, {"", "همه"}, {"confirmed", "تایید شده"}, {"rejected", "رد شده"}, {"cancelled", "لغو شده"}};
      bar.addView(Fx.chip(a, "💰 کیف پول", showWallet, v -> { showWallet = true; reload[0].run(); }), new LinearLayout.LayoutParams(Fx.WRAP, Fx.WRAP));
      for (final String[] x : f) { View c = Fx.chip(a, x[1], !showWallet && ordSt.equals(x[0]), v -> { showWallet = false; ordSt = x[0]; reload[0].run(); }); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Fx.WRAP, Fx.WRAP); p.setMarginStart(Fx.dp(a, 8)); bar.addView(c, p); }
      body.addView(Fx.text(a, "در حال بارگذاری…", 14, Fx.MU));
      if (showWallet) loadWallet(a, body, reload[0]); else loadOrders(a, body, reload[0]);
    };
    reload[0].run(); return scroller(a, box);
  }
  static void loadOrders(final BaseActivity a, final LinearLayout body, final Runnable reload) {
    Api.get("/api/admin/orders" + (ordSt.isEmpty() ? "" : "?status=" + ordSt), (r, e) -> { body.removeAllViews(); JSONArray o = r == null ? null : r.optJSONArray("orders");
      if (o == null || o.length() == 0) { body.addView(Fx.text(a, e != null ? e : "سفارشی وجود ندارد.", 15, Fx.MU)); return; }
      for (int i = 0; i < o.length(); i++) { final JSONObject x = o.optJSONObject(i); LinearLayout c = Fx.card(a);
        c.addView(Fx.text(a, Fx.num(x.optLong("qty")) + " سکه " + x.optString("coin_name") + " — " + ("sell".equals(x.optString("kind")) ? "فروش" : "خرید"), 17, Fx.GOLD2));
        c.addView(Fx.text(a, "کاربر: " + x.optString("username") + "  " + x.optString("phone"), 14, Fx.TX), Fx.lp(a, Fx.WRAP, Fx.WRAP, 6));
        c.addView(Fx.text(a, "مبلغ: " + Fx.num(x.optLong("amount")) + " تومان — دریافت در: " + ("wallet".equals(x.optString("dest")) ? "کیف پول" : "کارت " + x.optString("card")), 14, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 4));
        c.addView(Fx.text(a, "کد " + x.optString("code") + " — " + statusLabel(x.optString("status")) + " — " + dt(x.optLong("created_at")), 13, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 4));
        LinearLayout row = Fx.hbox(a); final String code = x.optString("code");
        if (x.optBoolean("has_shot")) row.addView(smallBtn(a, "📷 عکس", 0xFF9FB4FF, v -> showShot(a, "/api/admin/orders/" + code + "/shot")), Fx.wt(a, 1, 0));
        if ("review".equals(x.optString("status"))) { row.addView(smallBtn(a, "✅ تایید", 0xFF3DDC97, v -> act(a, "/api/admin/orders/" + code + "/confirm", false, reload)), Fx.wt(a, 1, 0)); row.addView(smallBtn(a, "❌ رد", 0xFFFF7A9C, v -> act(a, "/api/admin/orders/" + code + "/reject", true, reload)), Fx.wt(a, 1, 0)); }
        c.addView(row, Fx.lp(a, Fx.MATCH, Fx.WRAP, 10)); body.addView(c, top(a, 10)); } });
  }
  static void loadWallet(final BaseActivity a, final LinearLayout body, final Runnable reload) {
    Api.get("/api/admin/wallet", (r, e) -> { body.removeAllViews(); JSONArray o = list(r);
      if (o.length() == 0) { body.addView(Fx.text(a, e != null ? e : "درخواستی وجود ندارد.", 15, Fx.MU)); return; }
      for (int i = 0; i < o.length(); i++) { final JSONObject x = o.optJSONObject(i); LinearLayout c = Fx.card(a); String k = x.optString("kind");
        c.addView(Fx.text(a, ("topup".equals(k) ? "➕ شارژ" : "withdraw".equals(k) ? "➖ برداشت" : "📥 واریز فروش") + " — " + Fx.num(x.optLong("amount")) + " تومان", 17, Fx.GOLD2));
        c.addView(Fx.text(a, "کاربر: " + x.optString("username") + (TextUtils.isEmpty(x.optString("card")) ? "" : " — کارت " + x.optString("card")), 14, Fx.TX), Fx.lp(a, Fx.WRAP, Fx.WRAP, 6));
        c.addView(Fx.text(a, "کد " + x.optString("code") + " — " + statusLabel(x.optString("status")) + " — " + dt(x.optLong("created_at")), 13, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 4));
        LinearLayout row = Fx.hbox(a); final String code = x.optString("code");
        if (x.optBoolean("has_shot")) row.addView(smallBtn(a, "📷 عکس", 0xFF9FB4FF, v -> showShot(a, "/api/admin/wallet/" + code + "/shot")), Fx.wt(a, 1, 0));
        if ("pending".equals(x.optString("status"))) { row.addView(smallBtn(a, "topup".equals(k) ? "✅ تایید شارژ" : "✅ پرداخت شد", 0xFF3DDC97, v -> act(a, "/api/admin/wallet/" + code + "/confirm", false, reload)), Fx.wt(a, 1, 0)); row.addView(smallBtn(a, "❌ رد", 0xFFFF7A9C, v -> act(a, "/api/admin/wallet/" + code + "/reject", true, reload)), Fx.wt(a, 1, 0)); }
        c.addView(row, Fx.lp(a, Fx.MATCH, Fx.WRAP, 10)); body.addView(c, top(a, 10)); } });
  }
  // ---------- سکه‌ها ----------
  static View coins(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); box.addView(Ui.title(a, "🪙 مدیریت سکه‌ها")); final LinearLayout body = Fx.vbox(a);
    final Runnable[] load = new Runnable[1];
    load[0] = () -> { body.removeAllViews(); body.addView(Fx.button(a, "➕ سکه‌ی جدید", v -> coinForm(a, null, load[0])), top(a, 0));
      Api.get("/api/admin/coins", (r, e) -> { JSONArray cs = list(r); for (int i = 0; i < cs.length(); i++) { final JSONObject c = cs.optJSONObject(i); LinearLayout card = Fx.card(a);
        card.addView(Fx.text(a, "سکه " + c.optString("name") + (c.optBoolean("active", true) ? "" : "  (غیرفعال)"), 18, Fx.GOLD2));
        card.addView(Fx.text(a, "خرید: " + Fx.num(c.optLong("buy")) + " | فروش: " + Fx.num(c.optLong("sell")) + " | کارمزد: " + c.optString("commission") + "٪", 14, Fx.TX), Fx.lp(a, Fx.WRAP, Fx.WRAP, 6));
        card.addView(Fx.text(a, "موجودی: " + Fx.num(c.optLong("stock")) + " | سقف: " + Fx.num(c.optLong("cap")), 13, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 4));
        card.setOnClickListener(v -> coinForm(a, c, load[0])); body.addView(card, top(a, 10)); } }); };
    load[0].run(); box.addView(body, top(a, 12)); return scroller(a, box);
  }
  static void coinForm(final BaseActivity a, final JSONObject c, final Runnable reload) {
    LinearLayout f = Fx.vbox(a); f.setPadding(Fx.dp(a, 16), Fx.dp(a, 8), Fx.dp(a, 16), Fx.dp(a, 8));
    final String[] keys = {"name", "buy", "sell", "commission", "cap", "stock"}; final String[] labs = {"نام پلتفرم", "قیمت خرید", "قیمت فروش", "کارمزد فروش (٪)", "سقف", "موجودی"}; final EditText[] ed = new EditText[keys.length];
    for (int i = 0; i < keys.length; i++) { ed[i] = field(a, labs[i], c == null ? "" : c.optString(keys[i]), i == 0 ? InputType.TYPE_CLASS_TEXT : InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL); f.addView(ed[i], top(a, 8)); }
    final CheckBox act = new CheckBox(a); act.setText("فعال"); act.setTextColor(Fx.TX); act.setChecked(c == null || c.optBoolean("active", true)); f.addView(act, top(a, 8));
    ScrollView sv = new ScrollView(a); sv.addView(f);
    AlertDialog.Builder b = new AlertDialog.Builder(a).setTitle(c == null ? "سکه‌ی جدید" : "ویرایش " + c.optString("name")).setView(sv).setNegativeButton("انصراف", null)
      .setPositiveButton("ذخیره", (d, w) -> { JSONObject body = new JSONObject(); try { for (int i = 0; i < keys.length; i++) body.put(keys[i], faDigits(ed[i].getText().toString().trim())); body.put("active", act.isChecked()); } catch (Exception ex) { }
        Api.Cb cb = (r, e) -> { if (e != null) Fx.toast(a, e); reload.run(); };
        if (c == null) Api.post("/api/admin/coins", body, cb); else Api.put("/api/admin/coins/" + c.optString("id"), body, cb); });
    if (c != null) b.setNeutralButton("حذف", (d, w) -> Fx.confirm(a, "«" + c.optString("name") + "» حذف شود؟", () -> Api.delete("/api/admin/coins/" + c.optString("id"), (r, e) -> { if (e != null) Fx.toast(a, e); reload.run(); })));
    b.show();
  }
  // ---------- کاربران ----------
  static View users(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); box.addView(Ui.title(a, "👥 کاربران")); final LinearLayout body = Fx.vbox(a); box.addView(body); body.addView(Fx.text(a, "در حال بارگذاری…", 14, Fx.MU));
    final Runnable[] load = new Runnable[1];
    load[0] = () -> Api.get("/api/admin/users", (r, e) -> { body.removeAllViews(); JSONArray us = r == null ? null : r.optJSONArray("users"); if (us == null) { body.addView(Fx.text(a, e, 14, Fx.BAD)); return; }
      for (int i = 0; i < us.length(); i++) { final JSONObject u = us.optJSONObject(i); LinearLayout c = Fx.card(a);
        c.addView(Fx.text(a, u.optString("username") + (u.optBoolean("disabled") ? "  🚫 مسدود" : u.optBoolean("deleted") ? "  (حذف‌شده)" : ""), 17, Fx.GOLD2));
        c.addView(Fx.text(a, "موبایل: " + (u.optString("phone").isEmpty() ? "—" : u.optString("phone")) + "  |  کارت: " + (u.optString("card").isEmpty() ? "—" : u.optString("card")), 13, Fx.TX), Fx.lp(a, Fx.WRAP, Fx.WRAP, 6));
        c.addView(Fx.text(a, "کیف پول: " + Fx.num(u.optLong("balance")) + " ت  |  سفارش: " + Fx.num(u.optLong("orders")) + "  |  عضویت: " + dt(u.optLong("created_at")), 13, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 4));
        if (!"admin".equals(u.optString("role")) && !u.optBoolean("deleted")) c.addView(smallBtn(a, u.optBoolean("disabled") ? "رفع مسدودی" : "مسدود کردن", u.optBoolean("disabled") ? 0xFF3DDC97 : 0xFFFF7A9C, v -> act(a, "/api/admin/users/" + u.optString("id") + "/toggle", false, load[0])), Fx.lp(a, Fx.WRAP, Fx.WRAP, 10));
        body.addView(c, top(a, 10)); } });
    load[0].run(); return scroller(a, box);
  }
  // ---------- بیشتر ----------
  static View tile(final BaseActivity a, String emoji, String label, View.OnClickListener l) {
    LinearLayout t = Ui.navy(a); t.setGravity(Gravity.CENTER_HORIZONTAL); t.setPadding(Fx.dp(a, 10), Fx.dp(a, 22), Fx.dp(a, 10), Fx.dp(a, 22));
    t.addView(Ui.hex(a, emoji, 84)); t.addView(Fx.text(a, label, 17, Fx.TX), Fx.lp(a, Fx.WRAP, Fx.WRAP, 14)); t.setOnClickListener(l); return t;
  }
  static View more(final BaseActivity a) {
    LinearLayout box = Fx.vbox(a); box.addView(Ui.title(a, "☰ بیشتر"));
    box.addView(Ui.two(a, tile(a, "📣", "اعلانات", v -> a.push(page("📣 اعلانات", AdminActivity::ann))), tile(a, "💬", "پشتیبانی", v -> a.push(page("💬 نظرات کاربران", AdminActivity::support)))), top(a, 0));
    box.addView(Ui.two(a, tile(a, "🚪", "خروج", v -> Fx.confirm(a, "از پنل خارج می‌شوید؟", () -> { Session.clear(); a.replaceAll(new Auth.Login(NEXT, true)); })), tile(a, "⚙️", "تنظیمات", v -> a.push(page("⚙️ تنظیمات", AdminActivity::settings)))), top(a, 12));
    return scroller(a, box);
  }
  static View support(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); box.addView(Fx.text(a, "در حال بارگذاری…", 14, Fx.MU));
    Api.get("/api/admin/comments", (r, e) -> { box.removeAllViews(); JSONArray it = list(r); if (it.length() == 0) { box.addView(Fx.text(a, e != null ? e : "هنوز نظری ثبت نشده.", 15, Fx.MU)); return; }
      for (int i = 0; i < it.length(); i++) { JSONObject x = it.optJSONObject(i); LinearLayout c = Fx.card(a); c.addView(Fx.text(a, x.optString("username", "—") + " — " + dt(x.optLong("created_at")), 13, Fx.GOLD2)); c.addView(Fx.text(a, x.optString("text"), 15, Fx.TX), Fx.lp(a, Fx.WRAP, Fx.WRAP, 6)); box.addView(c, top(a, i == 0 ? 0 : 10)); } });
    return scroller(a, box);
  }
  static View ann(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); final LinearLayout body = Fx.vbox(a);
    final EditText t = field(a, "متن اعلان...", "", InputType.TYPE_CLASS_TEXT); final Runnable[] load = new Runnable[1];
    box.addView(t); box.addView(Fx.button(a, "افزودن", v -> { if (t.getText().toString().trim().isEmpty()) return; Api.post("/api/admin/announcements", Api.obj("text", t.getText().toString().trim()), (r, e) -> { if (e != null) Fx.toast(a, e); t.setText(""); load[0].run(); }); }), top(a, 10)); box.addView(body, top(a, 12));
    load[0] = () -> Api.get("/api/admin/announcements", (r, e) -> { body.removeAllViews(); JSONArray it = list(r);
      for (int i = 0; i < it.length(); i++) { final JSONObject x = it.optJSONObject(i); LinearLayout c = Fx.card(a); c.addView(Fx.text(a, x.optString("text"), 15, Fx.TX)); c.addView(Fx.text(a, (x.optBoolean("active") ? "فعال" : "غیرفعال") + " — " + dt(x.optLong("created_at")), 12, Fx.MU), Fx.lp(a, Fx.WRAP, Fx.WRAP, 4));
        LinearLayout row = Fx.hbox(a); row.addView(smallBtn(a, x.optBoolean("active") ? "غیرفعال" : "فعال", 0xFF9FB4FF, v -> act(a, "/api/admin/announcements/" + x.optString("id") + "/toggle", false, load[0])), Fx.wt(a, 1, 0));
        row.addView(smallBtn(a, "حذف", 0xFFFF7A9C, v -> Api.delete("/api/admin/announcements/" + x.optString("id"), (r2, e2) -> load[0].run())), Fx.wt(a, 1, 0)); c.addView(row, Fx.lp(a, Fx.MATCH, Fx.WRAP, 10)); body.addView(c, top(a, 10)); } });
    load[0].run(); return scroller(a, box);
  }
  static View settings(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); final String[] keys = {"owner_card", "owner_phone", "support_id", "channel_id"}; String[] labs = {"شماره کارت شما (برای شارژ کیف پول)", "شماره انتقال سکه", "آیدی پشتیبانی", "آیدی کانال"};
    final EditText[] ed = new EditText[4]; final CheckBox buy = new CheckBox(a); buy.setText("خرید سکه باز باشد"); buy.setTextColor(Fx.TX);
    LinearLayout c = Fx.card(a); box.addView(c);
    for (int i = 0; i < 4; i++) { c.addView(Ui.label(a, labs[i])); ed[i] = field(a, "", "", InputType.TYPE_CLASS_TEXT); c.addView(ed[i]); }
    c.addView(buy, top(a, 12)); final TextView msg = Fx.text(a, "", 14, Fx.OK);
    c.addView(Fx.button(a, "ذخیره", v -> { JSONObject b = new JSONObject(); try { b.put("buy_enabled", buy.isChecked() ? "1" : "0"); for (int i = 0; i < 4; i++) b.put(keys[i], faDigits(ed[i].getText().toString().trim())); } catch (Exception ex) { }
      Api.put("/api/admin/settings", b, (r, e) -> { msg.setText(e != null ? e : "ذخیره شد ✅"); msg.setTextColor(e != null ? Fx.BAD : Fx.OK); }); }), top(a, 14)); c.addView(msg, top(a, 8));
    Api.get("/api/admin/settings", (r, e) -> { JSONObject s = r == null ? null : r.optJSONObject("settings"); if (s == null) return; for (int i = 0; i < 4; i++) ed[i].setText(s.optString(keys[i])); buy.setChecked("1".equals(s.optString("buy_enabled"))); });
    return scroller(a, box);
  }
}
