package com.sekehchandeh.admin;
import android.content.Context;
import android.content.res.ColorStateList;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import com.sekehchandeh.core.*;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
public class AdminActivity extends BaseActivity {
  static final Auth.Next NEXT = new Auth.Next() { public Screen make() {
    return new TabsScreen("مدیریت سکه چنده", new TabsScreen.Tab[]{
      new TabsScreen.Tab("داشبورد", "chart", AdminActivity::dash), new TabsScreen.Tab("سکه‌ها", "coin", AdminActivity::coins), new TabsScreen.Tab("کلیدها", "gear", AdminActivity::switches)});
  } };
  @Override protected void start() {
    Api.onAuthFail = new Runnable() { public void run() { Session.clear(); Fx.toast(AdminActivity.this, "لطفاً دوباره وارد شوید."); replaceAll(new Auth.Login(NEXT, true)); } };
    replaceAll(new Auth.Splash(NEXT, true));
  }
  static ScrollView scroller(Context a, LinearLayout box) { int p = Fx.dp(a, 14); box.setPadding(p, p, p, p); ScrollView sc = new ScrollView(a); sc.addView(box); return sc; }
  static View stat(Context a, String label, String value) {
    LinearLayout c = Fx.card(a); c.setGravity(Gravity.CENTER);
    c.addView(Fx.gold(a, value, 26)); c.addView(Fx.text(a, label, 12, Fx.MU));
    return c;
  }
  static View dash(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); box.addView(Fx.text(a, "در حال بارگذاری…", 13, Fx.MU));
    Api.get("/api/admin/stats", (r, e) -> {
      box.removeAllViews();
      if (e != null) { box.addView(Fx.text(a, e, 14, Fx.BAD)); return; }
      LinearLayout r1 = Fx.hbox(a), r2 = Fx.hbox(a);
      r1.addView(stat(a, "کاربران", Fx.num(r.optLong("users"))), Fx.wt(a, 1, 0)); r1.addView(stat(a, "سفارش در انتظار", Fx.num(r.optLong("pending_orders"))), Fx.wt(a, 1, 0));
      r2.addView(stat(a, "درخواست کیف پول", Fx.num(r.optLong("pending_wallet"))), Fx.wt(a, 1, 0)); r2.addView(stat(a, "گفتگوی خوانده‌نشده", Fx.num(r.optLong("unread_chats"))), Fx.wt(a, 1, 0));
      box.addView(r1); box.addView(r2, Fx.lp(a, Fx.MATCH, Fx.WRAP, 8));
      int used = r.optInt("db_mb"), lim = Math.max(1, r.optInt("db_limit_mb"));
      LinearLayout dc = Fx.card(a); dc.addView(Fx.text(a, "فضای دیتابیس: " + Fx.num(used) + " از " + Fx.num(lim) + " مگابایت", 14, Fx.TX));
      LinearLayout bar = Fx.hbox(a); bar.setBackgroundColor(0xFF0B0805);
      View fill = new View(a); fill.setBackgroundColor(Fx.GOLD); bar.addView(fill, new LinearLayout.LayoutParams(0, Fx.dp(a, 10), Math.max(1, used)));
      bar.addView(new View(a), new LinearLayout.LayoutParams(0, Fx.dp(a, 10), Math.max(1, lim - used)));
      dc.addView(bar, Fx.lp(a, Fx.MATCH, Fx.WRAP, 8)); box.addView(dc, Fx.lp(a, Fx.MATCH, Fx.WRAP, 8));
      box.addView(Fx.ghost(a, "تازه‌سازی", v -> a.replaceAll(NEXT.make())), Fx.lp(a, Fx.MATCH, Fx.WRAP, 12));
      box.addView(Fx.button(a, "خروج از حساب", v -> Fx.confirm(a, "از حساب خارج می‌شوید؟", () -> { Session.clear(); a.replaceAll(new Auth.Login(NEXT, true)); })), Fx.lp(a, Fx.MATCH, Fx.WRAP, 12));
    });
    return scroller(a, box);
  }
  static View coins(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); final LinearLayout list = Fx.vbox(a);
    final Runnable[] load = new Runnable[1];
    box.addView(Fx.button(a, "افزودن سکه", v -> Fx.form(a, "سکه جدید", new String[]{"نام سکه", "قیمت خرید (تومان)", "قیمت فروش (تومان)"}, null,
      new int[]{InputType.TYPE_CLASS_TEXT, InputType.TYPE_CLASS_NUMBER, InputType.TYPE_CLASS_NUMBER}, "ذخیره", vals ->
        Api.post("/api/admin/coins", Api.obj("name", vals[0], "buy_price", vals[1], "sell_price", vals[2]), (r, e) -> { if (e != null) Fx.toast(a, e); else load[0].run(); }))));
    box.addView(list, Fx.lp(a, Fx.MATCH, Fx.WRAP, 12));
    load[0] = () -> {
      list.removeAllViews(); list.addView(Fx.text(a, "در حال بارگذاری…", 13, Fx.MU));
      Api.get("/api/admin/coins", (r, e) -> {
        list.removeAllViews();
        if (e != null) { list.addView(Fx.text(a, e, 14, Fx.BAD)); return; }
        JSONArray cs = r.optJSONArray("coins");
        if (cs == null || cs.length() == 0) { list.addView(Fx.text(a, "هنوز سکه‌ای ثبت نشده. با دکمه بالا اضافه کنید.", 14, Fx.MU)); return; }
        for (int i = 0; i < cs.length(); i++) {
          final JSONObject c = cs.optJSONObject(i);
          LinearLayout cd = Fx.card(a); cd.addView(Fx.gold(a, c.optString("name"), 18));
          cd.addView(Fx.text(a, "خرید: " + Fx.num(c.optLong("buy_price")) + "     فروش: " + Fx.num(c.optLong("sell_price")), 14, Fx.TX), Fx.lp(a, Fx.WRAP, Fx.WRAP, 6));
          LinearLayout row = Fx.hbox(a);
          Switch sw = new Switch(a); sw.setChecked(c.optBoolean("active")); sw.setText("فعال"); sw.setTextColor(Fx.MU);
          sw.setThumbTintList(ColorStateList.valueOf(Fx.GOLD)); sw.setTrackTintList(ColorStateList.valueOf(Fx.GOLD3));
          sw.setOnCheckedChangeListener((b, on) -> Api.put("/api/admin/coins/" + c.optInt("id"), Api.obj("active", on), (r2, e2) -> { if (e2 != null) Fx.toast(a, e2); }));
          row.addView(sw, new LinearLayout.LayoutParams(0, Fx.WRAP, 1f));
          row.addView(Fx.ghost(a, "ویرایش", v -> Fx.form(a, "ویرایش سکه", new String[]{"نام سکه", "قیمت خرید", "قیمت فروش"},
            new String[]{c.optString("name"), String.valueOf(c.optLong("buy_price")), String.valueOf(c.optLong("sell_price"))},
            new int[]{InputType.TYPE_CLASS_TEXT, InputType.TYPE_CLASS_NUMBER, InputType.TYPE_CLASS_NUMBER}, "ذخیره", vals ->
              Api.put("/api/admin/coins/" + c.optInt("id"), Api.obj("name", vals[0], "buy_price", vals[1], "sell_price", vals[2]), (r3, e3) -> { if (e3 != null) Fx.toast(a, e3); else load[0].run(); }))));
          cd.addView(row, Fx.lp(a, Fx.MATCH, Fx.WRAP, 10));
          list.addView(cd, Fx.lp(a, Fx.MATCH, Fx.WRAP, 10));
        }
      });
    };
    load[0].run();
    return scroller(a, box);
  }
  static View switches(final BaseActivity a) {
    final LinearLayout box = Fx.vbox(a); box.addView(Fx.text(a, "در حال بارگذاری…", 13, Fx.MU));
    Api.get("/api/admin/features", (r, e) -> {
      box.removeAllViews();
      if (e != null) { box.addView(Fx.text(a, e, 14, Fx.BAD)); return; }
      box.addView(Fx.text(a, "هر قابلیتی که خاموش کنید، برای همه کاربران بدون نیاز به APK جدید خاموش می‌شود.", 13, Fx.MU));
      JSONArray it = r.optJSONArray("items");
      for (int i = 0; it != null && i < it.length(); i++) {
        final JSONObject f = it.optJSONObject(i);
        LinearLayout cd = Fx.card(a); LinearLayout row = Fx.hbox(a);
        row.addView(Fx.text(a, f.optString("label"), 16, Fx.TX), new LinearLayout.LayoutParams(0, Fx.WRAP, 1f));
        Switch sw = new Switch(a); sw.setChecked(f.optBoolean("enabled"));
        sw.setThumbTintList(ColorStateList.valueOf(Fx.GOLD)); sw.setTrackTintList(ColorStateList.valueOf(Fx.GOLD3));
        sw.setOnCheckedChangeListener((b, on) -> Api.put("/api/admin/features/" + f.optString("key"), Api.obj("enabled", on), (r2, e2) -> { if (e2 != null) Fx.toast(a, e2); }));
        row.addView(sw); cd.addView(row); box.addView(cd, Fx.lp(a, Fx.MATCH, Fx.WRAP, 10));
      }
    });
    return scroller(a, box);
  }
}
